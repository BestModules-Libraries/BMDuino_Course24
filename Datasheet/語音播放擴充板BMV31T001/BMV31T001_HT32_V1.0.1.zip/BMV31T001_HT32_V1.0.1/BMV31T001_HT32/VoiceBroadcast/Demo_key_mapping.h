#include ht68fv022.inc

;****************************************
;COMMAND TRIGGER DEFINE
; HOW MANY COMMAND BE DEFINE
;****************************************
#define COMMANDABLE_NUM  0  ;;
