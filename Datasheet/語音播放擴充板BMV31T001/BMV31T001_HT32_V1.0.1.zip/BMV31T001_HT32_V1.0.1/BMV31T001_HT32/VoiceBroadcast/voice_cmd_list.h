/*! 
voice command list 
 */ 
#ifndef _VOICE_CMD_LIST_H 
#define _VOICE_CMD_LIST_H 

/*voice*/ 
#define VOC_1 		 (0x00) 
#define VOC_2 		 (0x01) 
#define VOC_3 		 (0x02) 
#define VOC_4 		 (0x03) 
#define VOC_5 		 (0x04) 
#define VOC_6 		 (0x05) 
#define VOC_7 		 (0x06) 
#define VOC_8 		 (0x07) 

/*sentence*/ 

#endif 
