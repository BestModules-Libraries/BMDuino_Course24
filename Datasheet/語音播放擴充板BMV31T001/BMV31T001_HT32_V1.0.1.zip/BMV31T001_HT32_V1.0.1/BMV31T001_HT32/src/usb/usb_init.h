#ifndef __USB_SERIAL_H
#define __USB_SERIAL_H

#ifdef __cplusplus
 extern "C" {
#endif
void USB_Serial(void);

#ifdef __cplusplus
}
#endif

#endif

