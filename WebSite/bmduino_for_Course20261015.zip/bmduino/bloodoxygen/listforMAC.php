<?php
/**
 * ============================================================================
 * 程式名稱：listforMAC.php
 * 功能說明：依據使用者傳入的 MAC 位址，查詢資料庫中該裝置的血氧與心跳
 *           歷史資料，並以 HTML 表格方式呈現於網頁上。
 * ============================================================================
 *
 * 【整體程式運作流程解說】
 *
 * 1. 引入外部資源：
 *    - 使用 include 引入 "../comlib.php"（通用函數庫）與
 *      "../Connections/iotcnn.php"（資料庫連線參數）。
 *    - 這兩個檔案提供 Connection() 連線函式以及 oxygentitle() 等共用函式。
 *
 * 2. 建立資料庫連線：
 *    - 呼叫 Connection() 取得 mysqli 連線物件 $link。
 *
 * 3. 檢查與取得 GET 參數：
 *    - 檢查 URL 中是否帶有 "MAC" 參數，若無則顯示錯誤訊息並終止程式。
 *    - 取得 MAC 參數後使用 trim() 移除首尾空白。
 *    - 若 MAC 為空字串，同樣顯示錯誤訊息並終止程式。
 *
 * 4. 準備 SQL 查詢：
 *    - 定義表格列模板 $subrow，用於後續 sprintf 產生每一列 HTML。
 *    - 定義 SQL 字串 $str，依 MAC 篩選 bloodoxygen 資料表，並依
 *      systime（時間）與 IP 遞增排序。
 *    - 使用 sprintf() 將 MAC 值帶入 SQL 字串，產生真正的查詢指令。
 *
 * 5. 初始化資料陣列：
 *    - 建立五個空陣列 $d01 ~ $d05，分別儲存：
 *      MAC、IP、systime（更新時間）、blood（血氧）、heartbeat（心跳）。
 *
 * 6. 執行查詢與讀取資料：
 *    - 使用 mysqli_query() 執行 SQL。
 *    - 若查詢成功，透過 while 迴圈逐列讀取 mysqli_fetch_array() 的結果，
 *      並使用 array_push() 將各欄位值分別存入對應陣列。
 *
 * 7. 釋放資源與關閉連線：
 *    - 使用 mysqli_free_result() 釋放查詢結果。
 *    - 使用 mysqli_close() 關閉資料庫連線。
 *
 * 8. 輸出 HTML 頁面：
 *    - 使用 XHTML 1.0 Frameset DTD 宣告。
 *    - head 中設定 UTF-8 編碼、網頁標題（呼叫 oxygentitle()）並載入
 *      /c08/webcss.css 樣式表。
 *    - body 中引入 ../toptitle.php 頁首。
 *    - 建立一個置中對齊的表格：
 *        * 第一列為合併 5 欄的標題列，底色 #CFC。
 *        * 第二列為各欄位名稱：MAC、IP、更新時間、血氧、心跳。
 *        * 之後使用 PHP for 迴圈，依 $d01 陣列長度逐列以 $subrow 模板
 *          與 sprintf() 產生資料列。
 *    - 最後引入 ../topfooter.php 頁尾。
 *
 * 【注意事項】
 * - 本程式直接將 GET 參數帶入 SQL 字串，未使用參數化查詢或跳脫處理，
 *   在正式環境中可能有 SQL Injection 風險，建議改用 prepared statement。
 * - $subrow 模板中的 %4.2f 對應血氧值（浮點數，顯示兩位小數），
 *   %d 對應心跳值（整數）。
 * ============================================================================
 */

// 引入資料庫連接和通用函數
include("../comlib.php");        // 通用函數庫
include("../Connections/iotcnn.php"); // 資料庫連接參數

// 建立與資料庫的連接
$link = Connection(); // Connection 是在 iotcnn.php 中定義的連接函數

// 確保 GET 參數中存在 "MAC"，如果沒有，則終止程式
if (!isset($_GET["MAC"])) {
    echo "MAC address lost <br>";
    die(); // 終止程式
}

// 獲取 MAC 地址參數，並移除首尾空格
$temp0 = trim($_GET["MAC"]);

// 如果 MAC 地址為空，則終止程式
if ($temp0 == "") {
    echo "MAC Address is empty string <br>";
    die(); // 終止程式
}
//Ultrasonic HC-SR04 Device(超音波測距裝置)
// 表格標題，包含 MAC 地址
//$tstr = oxygentitle();

// 定義表格行的模板，用於顯示資料
// %s：字串（MAC、IP、時間）；%4.2f：浮點數（血氧，總寬 4、小數 2 位）；%d：整數（心跳）
$subrow = "<tr><td>%s</td><td>%s</td><td>%s</td><td>%4.2f</td><td>%d</td></tr>";

// SQL 查詢字串，使用給定的 MAC 地址
// 依 systime 與 IP 遞增排序，讓資料依時間順序呈現
$str = "SELECT * FROM bloodoxygen  WHERE MAC = '%s' order by systime,IP asc";

// 產生真正SQL 查詢字串，格式化查詢字串，替換占位符
$qrystr = sprintf($str, $temp0);

// 建立空陣列，用於儲存查詢結果
$d01 = array(); // MAC 地址
$d02 = array(); // IP 地址
$d03 = array(); // 更新時間
$d04 = array(); // 血氧資料
$d05 = array(); // 心跳資料


// 執行 SQL 查詢，將結果存入 $result
$result = mysqli_query($link, $qrystr);

// 如果查詢成功，開始處理資料
if ($result !== FALSE) 
{
    // 逐行讀取資料，並將其存入對應的陣列
    while ($row = mysqli_fetch_array($result)) 
    {
        array_push($d01, $row["MAC"]);  // MAC 地址
        array_push($d02, $row["IP"]);   // IP 地址
        array_push($d03, $row["systime"]); // 資料日期時間
        array_push($d04, $row["blood"]); // 血氧資料
        array_push($d05, $row["heartbeat"]); // 心跳資料
    }
}

// 釋放查詢結果資源
mysqli_free_result($result);

// 關閉資料庫連接
mysqli_close($link);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- 設定網頁的標題和數據字元碼  -->
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title><?php oxygentitle(); ?></title>
            <link rel="stylesheet" href="/c08/webcss.css"> <!-- 加載 CSS 樣式 -->
</head>
<body>
    <!-- 包含標題內容 -->
    <?php include("../toptitle.php"); ?>

    <!-- 建立居中對齊的表格 -->
    <div align="center">
        <table border="1" align="center" cellspacing="1" cellpadding="1">
            <!-- 表格標題行（合併 5 欄，底色 #CFC 為淺綠色） -->
            <tr bgcolor="#CFC">
                <td colspan="5">
                    <div align="center">
                        <?php oxygentitle(); ?> <!-- 表格標題，包含 MAC 地址 -->
                    </div>
                </td>
            </tr>
            <!-- 表格列標題 -->
            <tr>
                <td>MAC Address(網卡編號)</td>
                <td>IP Address(用戶端 IP)</td>
                <td>Update Time(更新時間)</td>
                <td>Blood Oxygen(血氧資料)</td>
                <td>Heart Beat(心跳資料)</td>
            </tr>

            <!-- 使用 PHP 迴圈生成表格內容 -->
            <?php 
            if (count($d01) > 0) { // 如果有資料
                for ($i = 0; $i < count($d01); $i++) { // 逐行顯示
                    // 使用 $subrow 模板和 sprintf 生成表格行
                    echo sprintf($subrow, $d01[$i], $d02[$i], $d03[$i], $d04[$i], $d05[$i]);
                }
            }
            ?>
        </table>
    </div>

    <!-- 包含頁腳內容 -->
    <?php include("../topfooter.php"); ?>
</body>
</html>