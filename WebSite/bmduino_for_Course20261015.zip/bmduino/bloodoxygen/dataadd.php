<?php
/**
 * ============================================================================
 * 程式名稱：dataadd.php（血氧與心跳資料上傳 API）
 * 功能說明：接收 IoT 血氧機上傳的血氧值與心跳值，寫入 MySQL 的 bloodoxygen 資料表
 * ============================================================================
 *
 * 【整體程式運作解說】
 * ----------------------------------------------------------------------------
 * 本程式為一支提供給 IoT 裝置（例如：Arduino + 血氧/心跳感測器）透過 HTTP
 * GET 方式上傳「血氧值（blood）」與「心跳值（heartbeat）」的 API 端點。
 *
 * 一、使用方式（範例網址）：
 *   http://iot.arduino.org.tw:8888/c08/bloodoxygen/dataadd.php?MAC=AABBCCDDEEFF&bd=97.45&hb=83
 *
 *   其中 GET 參數：
 *     - MAC：裝置的 MAC 位址（例如 AABBCCDDEEFF）
 *     - bd ：血氧濃度值（Blood Oxygen，浮點數，例如 97.45）
 *     - hb ：心跳值（Heart Beat，整數，例如 83）
 *
 * 二、程式執行流程：
 *   1. 引入資料庫連線檔（../Connections/iotcnn.php），並呼叫 Connection()
 *      產生 MySQL 連線物件 $link。
 *   2. 使用 getenv("REMOTE_ADDR") 取得用戶端連線 IP，並輸出至網頁方便偵錯。
 *   3. 透過 $_GET 取得三個參數：
 *        - $temp0：MAC 位址
 *        - $temp1：血氧值（bd）
 *        - $temp2：心跳值（hb）
 *   4. 呼叫自訂函式 getdatetime() 取得系統時間，格式為 YYYYMMDDHHMMSS。
 *   5. 使用 sprintf() 組合 INSERT SQL 語法，將資料新增至 bloodoxygen 資料表：
 *        INSERT INTO bloodoxygen (MAC, IP, systime, blood, heartbeat)
 *        VALUES ('MAC', 'IP', '系統時間', 血氧值, 心跳值);
 *      其中：
 *        - %s    → 字串（MAC、IP、systime）
 *        - %6.2f → 浮點數，保留小數 2 位（blood）
 *        - %d    → 整數（heartbeat）
 *   6. 輸出組合後的 SQL 語法（方便除錯）。
 *   7. 以 mysqli_query() 執行 SQL：
 *        - 成功 → 印出 "Successful"
 *        - 失敗 → 印出 "Fail"
 *   8. 關閉資料庫連線 mysqli_close($link)。
 *
 * 三、資料表結構參考（bloodoxygen）：
 *   CREATE TABLE bloodoxygen (
 *     id          INT AUTO_INCREMENT PRIMARY KEY,
 *     crtdatetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- 資料建立時間
 *     systime     VARCHAR(14),  -- 系統時間字串（YYYYMMDDHHMMSS）
 *     MAC         VARCHAR(20),  -- 裝置 MAC 位址
 *     IP          VARCHAR(45),  -- 上傳端 IP
 *     blood       DECIMAL(6,2), -- 血氧值
 *     heartbeat   INT           -- 心跳值
 *   );
 *
 * 四、附帶的自訂函式（位於檔案後半段）：
 *   - getdataorder($dt)  ：將日期時間字串轉為 YYYYMMDDHHMMSS 格式。
 *   - getdataorder2($dt) ：將日期時間字串轉為 YYYYMMDDHHMM 格式（至分鐘）。
 *   - getdatetime()      ：取得目前系統時間，回傳 YYYYMMDDHHMMSS 格式。
 *   - trandatetime1($dt) ：將 YYYYMMDDHHMMSS 字串轉回可讀的
 *                          YYYY/MM/DD HH:MM:SS 格式。
 *
 * 五、注意事項：
 *   - 本程式使用 GET 傳遞參數，若用於公開環境建議改用 POST 並加入驗證機制。
 *   - 本程式未檢查 MAC、bd、hb 參數是否存在，若未傳入會產生 PHP Notice；
 *     建議加入 isset() 檢查以避免錯誤訊息外洩。
 *   - SQL 語法使用 sprintf() 直接代入參數，若參數來自使用者輸入，可能會有
 *     SQL Injection 風險，建議改用 mysqli_prepare() 搭配參數化查詢。
 *   - 程式碼中並無 HTML 或 JavaScript，僅為純 PHP 後端 API 程式。
 * ============================================================================
 */

    // 引入資料庫連線設定檔 (iotcnn.php)，這個檔案內含有 Connection() 函式可建立與 MySQL 的連線
    include("../Connections/iotcnn.php");		

    // 呼叫自訂函式 Connection() 來建立與 MySQL 資料庫的連線，並回傳一個連線物件給 $link
    $link = Connection();		

    // 使用 getenv() 取得目前使用者端的連線 IP 位址
    $ip = getenv("REMOTE_ADDR");	
    echo "ip:".$ip."<br>";   // 輸出取得的 IP 位址到網頁上，方便偵錯或確認來源

    // 透過 GET 方式取得網址參數 (來自感測器或裝置上傳的資料)
    $temp0 = $_GET["MAC"];   // MAC Address (裝置唯一位址)
    $temp1 = $_GET["bd"];    // 血氧濃度值 (blood oxygen)
    $temp2 = $_GET["hb"];    // 心跳值 (heartbeat)

    // 呼叫自訂函式 getdatetime() 來取得系統目前的時間，格式為 YYYYMMDDHHMMSS
    $sysdt = getdatetime() ;

    // 範例傳入網址：
    // http://iot.arduino.org.tw:8888/c08/bloodoxygen/dataadd.php?MAC=AABBCCDDEEFF&bd=97.45&hb=83
    
    // 範例資料表插入語法：
    // INSERT INTO `bloodoxygen` (`id`, `crtdatetime`, `systime`, `MAC`, `IP`, `blood`, `heartbeat`) 
    // VALUES ('', current_timestamp(), '20250920155501', 'AABBCCDDEEFF', '192.168.99.100', '96.76', '93');

    // 定義 SQL 新增語法的格式字串，%s 表示字串，%6.2f 表示浮點數(小數2位)，%d 表示整數
    $qrycmd = "insert into bloodoxygen (MAC,IP,systime, blood, heartbeat) values ('%s', '%s','%s', %6.2f, %d);";

    // 使用 sprintf() 將上面 $qrycmd 的格式字串依序填入變數，組合出完整的 SQL 語法
    // 參數順序：MAC、IP、系統時間、血氧值、心跳值
    $qrystr = sprintf($qrycmd, $temp0, $ip, $sysdt, $temp1, $temp2); 

    // 顯示產生的 SQL 語法，方便偵錯
    echo $qrystr ;
    echo "<br>" ;

    // 執行 SQL 新增語法，若成功則顯示 "Successful"，失敗則顯示 "Fail"
    if (mysqli_query($link, $qrystr))
    {
        echo "Successful <br>" ;
    }
    else
    {
        echo "Fail <br>" ;
    }

    echo "<br>" ;
    // 關閉與 MySQL 資料庫的連線
    mysqli_close($link);		
?>
    
<?php
    /* 定義自訂 PHP 函式 */

/**
 * 將日期字串轉換成排序用格式 (YYYYMMDDHHMMSS)
 * @param string $dt 日期時間字串（例如 "2025-09-20 15:55:01"）
 * @return string YYYYMMDDHHMMSS 格式字串
 */
function getdataorder($dt) {
	// 將字串依空白分割成日期(ymd) 與 時間(hms)
	$splitTimeStamp = explode(" ", $dt);
	$ymd = $splitTimeStamp[0] ;
	$hms = $splitTimeStamp[1] ;

	// 將日期拆解成年、月、日
	$vdate = explode('-', $ymd);
	// 將時間拆解成時、分、秒
	$vtime = explode(':', $hms);

	// 使用 str_pad() 補齊字串長度，例如 "9" → "09"
	$yyyy = str_pad($vdate[0], 4, "0", STR_PAD_LEFT);  // 年補零至 4 位
	$mm   = str_pad($vdate[1], 2, "0", STR_PAD_LEFT);  // 月補零至 2 位
	$dd   = str_pad($vdate[2], 2, "0", STR_PAD_LEFT);  // 日補零至 2 位
	$hh   = str_pad($vtime[0], 2, "0", STR_PAD_LEFT);  // 時補零至 2 位
	$min  = str_pad($vtime[1], 2, "0", STR_PAD_LEFT);  // 分補零至 2 位
	$sec  = str_pad($vtime[2], 2, "0", STR_PAD_LEFT);  // 秒補零至 2 位

	// 回傳合併後的時間字串 (YYYYMMDDHHMMSS)
	return ($yyyy.$mm.$dd.$hh.$min.$sec) ;
}

/**
 * 與 getdataorder 類似，但回傳結果只到分鐘 (YYYYMMDDHHMM)
 * @param string $dt 日期時間字串（例如 "2025-09-20 15:55:01"）
 * @return string YYYYMMDDHHMM 格式字串
 */
function getdataorder2($dt) {
	$splitTimeStamp = explode(" ", $dt);
	$ymd = $splitTimeStamp[0] ;
	$hms = $splitTimeStamp[1] ;

	$vdate = explode('-', $ymd);  // 分割日期為年、月、日
	$vtime = explode(':', $hms);  // 分割時間為時、分、秒

	$yyyy = str_pad($vdate[0], 4, "0", STR_PAD_LEFT);  // 年
	$mm   = str_pad($vdate[1], 2, "0", STR_PAD_LEFT);  // 月
	$dd   = str_pad($vdate[2], 2, "0", STR_PAD_LEFT);  // 日
	$hh   = str_pad($vtime[0], 2, "0", STR_PAD_LEFT);  // 時
	$min  = str_pad($vtime[1], 2, "0", STR_PAD_LEFT);  // 分

	return ($yyyy.$mm.$dd.$hh.$min) ;  // 回傳 YYYYMMDDHHMM
}

/**
 * 取得目前系統時間，並回傳格式為 YYYYMMDDHHMMSS
 * @return string YYYYMMDDHHMMSS 格式字串
 */
function getdatetime() {
	$dt = getdate() ;  // 取得目前系統日期時間陣列
	$yyyy = str_pad($dt['year'], 4, "0", STR_PAD_LEFT);     // 年
	$mm   = str_pad($dt['mon'], 2, "0", STR_PAD_LEFT);      // 月
	$dd   = str_pad($dt['mday'], 2, "0", STR_PAD_LEFT);     // 日
	$hh   = str_pad($dt['hours'], 2, "0", STR_PAD_LEFT);    // 時
	$min  = str_pad($dt['minutes'], 2, "0", STR_PAD_LEFT);  // 分
	$sec  = str_pad($dt['seconds'], 2, "0", STR_PAD_LEFT);  // 秒

	return ($yyyy.$mm.$dd.$hh.$min.$sec) ;  // 回傳組合後的字串
}

/**
 * 將 YYYYMMDDHHMMSS 格式轉換成標準可讀格式 (YYYY/MM/DD HH:MM:SS)
 * @param string $dt YYYYMMDDHHMMSS 格式字串
 * @return string YYYY/MM/DD HH:MM:SS 格式字串
 */
function trandatetime1($dt) {
	$yyyy = substr($dt, 0, 4);   // 取出年
	$mm   = substr($dt, 4, 2);   // 取出月
	$dd   = substr($dt, 6, 2);   // 取出日
	$hh   = substr($dt, 8, 2);   // 取出時
	$min  = substr($dt, 10, 2);  // 取出分
	$sec  = substr($dt, 12, 2);  // 取出秒

	return ($yyyy."/".$mm."/".$dd." ".$hh.":".$min.":".$sec) ;  // 組合成可讀格式
}
?>