<!DOCTYPE html>
<html lang="zh-Hant">
<?php
// 載入共用函式庫，例如自定義的工具函數
include("../comlib.php");

// 載入資料庫連線設定與函數（應該定義有 Connection() 函數）
include("../Connections/iotcnn.php");

// 使用 Connection() 函式建立與資料庫的連線
$link = Connection();

// 取得所有 MAC 清單，供下拉選單使用（假設資料表名稱為 bloodoxygen）
$qrystr = "SELECT MAC FROM bloodoxygen WHERE 1 GROUP BY MAC ORDER BY MAC ASC";

$d01 = array(); // 用於儲存 MAC 地址

$result = mysqli_query($link, $qrystr);
if ($result) {
    while ($row = mysqli_fetch_array($result)) {
        $d01[] = $row["MAC"];
    }
    mysqli_free_result($result);
}
// 關閉連線（此頁之後只靠 genjsondata.php 取資料）
mysqli_close($link);
?>
<head>
  <meta charset="utf-8" />
  <title><?php oxygenchatrttitle(); ?></title>

  <!-- RWD -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Chart.js CDN -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    body {
      font-family: "Microsoft JhengHei", Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    .wrapper {
      max-width: 1100px;
      margin: 0 auto;
      padding: 16px;
    }
    h1 {
      font-size: 24px;
      margin-bottom: 12px;
    }
    h2 {
      font-size: 18px;
      margin-top: 24px;
      margin-bottom: 8px;
    }
    .form-row {
      margin-bottom: 12px;
    }
    label {
      margin-right: 4px;
    }
    input[type="text"],
    select {
      padding: 4px 6px;
      margin-right: 8px;
    }
    button {
      padding: 6px 12px;
      cursor: pointer;
    }
    .chart-block {
      margin-top: 8px;
      margin-bottom: 24px;
      height: 360px;
    }
    canvas {
      width: 100%;
      max-width: 1100px;
      height: 100%;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <h1><?php oxygenchatrttitle(); ?></h1>

    <!-- 查詢條件區：MAC + 起始日 + 結束日 -->
    <div class="form-row">
      <label for="mac">MAC：</label>
      <select id="mac">
        <?php
        if (count($d01) > 0) {
            foreach ($d01 as $mac) {
                echo "<option value=\"{$mac}\">{$mac}</option>";
            }
        } else {
            echo "<option value=\"\">（尚無 MAC 資料）</option>";
        }
        ?>
      </select>

      <label for="start">起始日(YYYYMMDD)：</label>
      <input type="text" id="start" value="20200406" />

      <label for="end">結束日(YYYYMMDD)：</label>
      <input type="text" id="end" value="20251231" />

      <button onclick="loadData()">查詢資料</button>
    </div>

    <!-- 圖表 1：血氧資料圖表 -->
    <h2>血氧資料圖表</h2>
    <div class="chart-block">
      <canvas id="chartOxygen"></canvas>
    </div>

    <!-- 圖表 2：心跳資料圖表 -->
    <h2>心跳資料圖表</h2>
    <div class="chart-block">
      <canvas id="chartHeart"></canvas>
    </div>

    <!-- 圖表 3：血氧 + 心跳雙 Y 軸圖表 -->
    <h2>血氧與心跳整合圖表</h2>
    <div class="chart-block">
      <canvas id="chartBoth"></canvas>
    </div>
  </div>

  <script>
    // 全域變數：用來存放 Chart.js 圖表物件，方便更新時先銷毀
    let oxygenChart = null;
    let heartChart = null;
    let bothChart = null;

    // 從後端 genjsondata.php 取得 JSON，然後畫三個 Chart.js 曲線圖
    function loadData() {
      const mac = document.getElementById('mac').value;
      const start = document.getElementById('start').value;
      const end = document.getElementById('end').value;

      if (!mac) {
        alert('請先選擇 MAC！');
        return;
      }

      if (!start || !end) {
        alert('請輸入起始日與結束日（YYYYMMDD）');
        return;
      }

      // 依照指定的網址格式呼叫 bloodoxygen 的 genjsondata.php
      const url =
        'http://iot.arduino.org.tw:8888/c08/bloodoxygen/genjsondata.php'
        + '?MAC=' + encodeURIComponent(mac)
        + '&start=' + encodeURIComponent(start)
        + '&end=' + encodeURIComponent(end);

      fetch(url)
        .then(function (response) {
          if (!response.ok) {
            throw new Error('HTTP 錯誤，狀態碼：' + response.status);
          }
          return response.json();
        })
        .then(function (json) {
          // 期待回傳格式中有 DateTime、Oxygen、HeartBeat 三個陣列
          const dateTime = json.DateTime;
          const oxygen = json.Oxygen;
          const heartbeat = json.HeartBeat;

          if (!dateTime || !oxygen || !heartbeat || dateTime.length === 0) {
            alert('查詢區間內沒有資料或資料格式不正確');
            destroyCharts();
            return;
          }

          // 將血氧與心跳資料轉成數字
          const oxygenData = oxygen.map(function (v) {
            const n = parseFloat(v);
            return isNaN(n) ? null : n;
          });
          const heartData = heartbeat.map(function (v) {
            const n = parseFloat(v);
            return isNaN(n) ? null : n;
          });

          // 計算血氧平均值（忽略 null）
          const validOxy = oxygenData.filter(function (v) { return v !== null; });
          const avgOxy = validOxy.length > 0
            ? validOxy.reduce(function (a, b) { return a + b; }, 0) / validOxy.length
            : 0;

          // 計算心跳平均值（忽略 null）
          const validHeart = heartData.filter(function (v) { return v !== null; });
          const avgHeart = validHeart.length > 0
            ? validHeart.reduce(function (a, b) { return a + b; }, 0) / validHeart.length
            : 0;

          drawOxygenChart(mac, start, end, dateTime, oxygenData, avgOxy);
          drawHeartChart(mac, start, end, dateTime, heartData, avgHeart);
          drawBothChart(mac, start, end, dateTime, oxygenData, heartData, avgOxy, avgHeart);
        })
        .catch(function (error) {
          console.error('讀取資料時發生錯誤：', error);
          alert('讀取資料時發生錯誤，請稍後再試或檢查伺服器。');
          destroyCharts();
        });
    }

    // 銷毀舊的圖表
    function destroyCharts() {
      if (oxygenChart !== null) {
        oxygenChart.destroy();
        oxygenChart = null;
      }
      if (heartChart !== null) {
        heartChart.destroy();
        heartChart = null;
      }
      if (bothChart !== null) {
        bothChart.destroy();
        bothChart = null;
      }
    }

    // 圖表 1：血氧資料圖表 + 平均線
    function drawOxygenChart(mac, start, end, categories, oxygenData, avgOxy) {
      const ctx = document.getElementById('chartOxygen').getContext('2d');
      if (oxygenChart !== null) {
        oxygenChart.destroy();
      }

      // 平均線資料：每個 x 對應同一個平均值
      const avgOxyData = categories.map(function () {
        return avgOxy;
      });

      oxygenChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: categories,
          datasets: [
            {
              label: '血氧 (Spo2 %)',
              data: oxygenData,
              borderColor: 'rgba(75, 192, 192, 1)',
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3,
            },
            {
              label: '血氧平均值 (' + (isFinite(avgOxy) ? avgOxy.toFixed(2) : 'N/A') + ' %)',
              data: avgOxyData,
              borderColor: 'rgba(255, 159, 64, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0  // 直線
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: '血氧資料圖表（MAC：' + mac + '，期間：' + start + ' ~ ' + end + '）',
              font: {
                size: 16
              }
            },
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function (ctx) {
                  const v = ctx.parsed.y;
                  if (v != null && isFinite(v)) {
                    // 根據 dataset 不同顯示不同文字
                    if (ctx.datasetIndex === 0) {
                      return '血氧: ' + v.toFixed(2) + ' %';
                    } else {
                      return '平均血氧: ' + v.toFixed(2) + ' %';
                    }
                  }
                  return '—';
                }
              }
            }
          },
          interaction: {
            mode: 'index',
            intersect: false,
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '量測時間（DateTime）'
              },
              ticks: {
                maxRotation: 60,
                minRotation: 45
              }
            },
            y: {
              title: {
                display: true,
                text: '血氧 (Spo2 %)'
              },
              suggestedMin: 80,
              suggestedMax: 100
            }
          }
        }
      });
    }

    // 圖表 2：心跳資料圖表 + 平均線
    function drawHeartChart(mac, start, end, categories, heartData, avgHeart) {
      const ctx = document.getElementById('chartHeart').getContext('2d');
      if (heartChart !== null) {
        heartChart.destroy();
      }

      // 平均線資料
      const avgHeartData = categories.map(function () {
        return avgHeart;
      });

      heartChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: categories,
          datasets: [
            {
              label: '心跳 (BPM)',
              data: heartData,
              borderColor: 'rgba(255, 99, 132, 1)',
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3,
            },
            {
              label: '心跳平均值 (' + (isFinite(avgHeart) ? avgHeart.toFixed(2) : 'N/A') + ' BPM)',
              data: avgHeartData,
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: '心跳資料圖表（MAC：' + mac + '，期間：' + start + ' ~ ' + end + '）',
              font: {
                size: 16
              }
            },
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function (ctx) {
                  const v = ctx.parsed.y;
                  if (v != null && isFinite(v)) {
                    if (ctx.datasetIndex === 0) {
                      return '心跳: ' + v.toFixed(0) + ' 次/分';
                    } else {
                      return '平均心跳: ' + v.toFixed(2) + ' 次/分';
                    }
                  }
                  return '—';
                }
              }
            }
          },
          interaction: {
            mode: 'index',
            intersect: false,
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '量測時間（DateTime）'
              },
              ticks: {
                maxRotation: 60,
                minRotation: 45
              }
            },
            y: {
              title: {
                display: true,
                text: '心跳 (BPM)'
              }
            }
          }
        }
      });
    }

    // 圖表 3：血氧 + 心跳 雙 Y 軸圖表 + 各自平均線
    function drawBothChart(mac, start, end, categories, oxygenData, heartData, avgOxy, avgHeart) {
      const ctx = document.getElementById('chartBoth').getContext('2d');
      if (bothChart !== null) {
        bothChart.destroy();
      }

      const avgOxyData = categories.map(function () {
        return avgOxy;
      });
      const avgHeartData = categories.map(function () {
        return avgHeart;
      });

      bothChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: categories,
          datasets: [
            {
              label: '血氧 (Spo2 %)',
              data: oxygenData,
              borderColor: 'rgba(75, 192, 192, 1)',
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3,
              yAxisID: 'oxygenAxis'
            },
            {
              label: '血氧平均 (' + (isFinite(avgOxy) ? avgOxy.toFixed(2) : 'N/A') + ' %)',
              data: avgOxyData,
              borderColor: 'rgba(255, 206, 86, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0,
              yAxisID: 'oxygenAxis'
            },
            {
              label: '心跳 (BPM)',
              data: heartData,
              borderColor: 'rgba(255, 99, 132, 1)',
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3,
              yAxisID: 'heartAxis'
            },
            {
              label: '心跳平均 (' + (isFinite(avgHeart) ? avgHeart.toFixed(2) : 'N/A') + ' BPM)',
              data: avgHeartData,
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0,
              yAxisID: 'heartAxis'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: '血氧與心跳整合圖表（MAC：' + mac + '，期間：' + start + ' ~ ' + end + '）',
              font: {
                size: 16
              }
            },
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function (ctx) {
                  const label = ctx.dataset.label || '';
                  const v = ctx.parsed.y;
                  if (v == null || !isFinite(v)) return label + ': —';

                  if (ctx.dataset.yAxisID === 'oxygenAxis') {
                    if (ctx.datasetIndex === 0) {
                      return '血氧: ' + v.toFixed(2) + ' %';
                    } else {
                      return '平均血氧: ' + v.toFixed(2) + ' %';
                    }
                  } else {
                    if (ctx.datasetIndex === 2) {
                      return '心跳: ' + v.toFixed(0) + ' 次/分';
                    } else {
                      return '平均心跳: ' + v.toFixed(2) + ' 次/分';
                    }
                  }
                }
              }
            }
          },
          interaction: {
            mode: 'index',
            intersect: false,
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '量測時間（DateTime）'
              },
              ticks: {
                maxRotation: 60,
                minRotation: 45
              }
            },
            oxygenAxis: {
              type: 'linear',
              position: 'left',
              title: {
                display: true,
                text: '血氧 (Spo2 %)'
              },
              suggestedMin: 80,
              suggestedMax: 100
            },
            heartAxis: {
              type: 'linear',
              position: 'right',
              title: {
                display: true,
                text: '心跳 (BPM)'
              },
              grid: {
                drawOnChartArea: false // 右邊 Y 軸不畫格線，避免太亂
              }
            }
          }
        }
      });
    }

    // 頁面載入時，直接先畫一次（使用預設值）
    window.addEventListener('load', function () {
      loadData();
    });
  </script>

  <!-- 在這一行「上面」已經有三個 Chart.js 的曲線圖 -->
  <?php
  include '../topfooter.php';
  ?>
</body>
</html>
