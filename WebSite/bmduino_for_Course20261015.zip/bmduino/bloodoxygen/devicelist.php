<?php
/*
================================================================================
 程式名稱：devicelist.php
 程式功能：溫溼度感測器裝置列表頁面（實際上為血氧/心跳感測器資料彙總列表）
================================================================================

【程式運作流程解說】

1. 啟動會話（session_start）
   - 啟動 PHP 會話機制，確保後續在連線資料庫與查詢前，相關的會話變數能正確初始化。

2. 引入外部檔案
   - include("../comlib.php")：引入通用函數庫，內含 oxygentitle() 等自訂函式。
   - include("../Connections/iotcnn.php")：引入資料庫連線參數檔，內含 Connection() 函式。

3. 建立資料庫連線
   - 呼叫 Connection() 取得 mysqli 連線物件 $link。

4. 定義格式化模板
   - $subrow：定義表格每一列的 HTML 模板，使用 sprintf 格式化輸出。
     欄位依序為：MAC、血氧平均值、心跳平均值、起始時間、結束時間、筆數、明細連結。
   - $op1：定義「明細查詢」超連結的 HTML 模板，點擊後導向 listforMAC.php 並帶入 MAC 參數。

5. 執行 SQL 查詢
   - 查詢語法：從 bloodoxygen 資料表中，依 MAC 位址分組，
     計算每台裝置的血氧平均值（blood）、心跳平均值（heartbeat）、
     最新時間（max systime）、最舊時間（min systime）以及資料筆數（count）。
   - 依 systime 降冪排序，讓最新有資料的裝置排在前面。

6. 處理查詢結果
   - 建立六個空陣列 $d01 ~ $d06，分別存放：
       $d01 → MAC 位址
       $d02 → 起始時間（min systime）
       $d03 → 結束時間（max systime）
       $d04 → 血氧平均值（blood）
       $d05 → 心跳平均值（heartbeat）
       $d06 → 資料筆數（count）
   - 使用 while 迴圈逐列讀取 mysqli_fetch_array 的結果，並以 array_push 存入對應陣列。

7. 釋放資源與關閉連線
   - mysqli_free_result($result)：釋放查詢結果所佔用的記憶體。
   - mysqli_close($link)：關閉資料庫連線。

8. 輸出 HTML 頁面
   - 使用 XHTML 1.0 Frameset DTD 宣告。
   - 載入 /c08/webcss.css 樣式表。
   - 呼叫 oxygentitle() 輸出頁面標題。
   - include("../toptitle.php")：引入頁首內容。
   - 建立置中對齊的表格，標題列背景色為 #CFC。
   - 表格欄位：MAC Address、BloodOxygen、HeartBeat、Start Date Time、
     End Date Time、Records Count、Query Detail。
   - 使用 for 迴圈遍歷 $d01 陣列，透過 sprintf 將每筆資料套入 $subrow 模板輸出。
   - 每列的「明細查詢」連結透過 sprintf($op1, MAC) 產生。
   - include("../topfooter.php")：引入頁尾內容。

【注意事項】
- 本程式註解中提到的「溫溼度感測器」與實際 SQL 查詢的 bloodoxygen 資料表
  （血氧/心跳）不一致，推測為沿用舊範例註解，實際功能為血氧心跳裝置列表。
- $subrow 模板中有 7 個 %s/%f/%d 佔位符，對應 7 個欄位，需確保傳入參數數量一致。
- SQL 使用 avg() 與 max()/min() 聚合函數，搭配 group by MAC，
  因此每台 MAC 只會輸出一列彙總結果。
================================================================================
*/

// 啟動 PHP 會話，確保在連線和查詢資料庫前正確初始化
session_start();

// 引入外部檔案，這些檔案包含資料庫連接和其他功能
include("../comlib.php");        // 通用函數庫
include("../Connections/iotcnn.php"); // 資料庫連接參數

// 建立與資料庫的連接
$link = Connection(); // Connection 是在 iotcnn.php 中定義的連接函數

// 格式化表格每一行的模板
// 依序對應：MAC(%s)、血氧平均值(%f)、心跳平均值(%f)、起始時間(%s)、結束時間(%s)、筆數(%d)、明細連結(%s)
$subrow = "<tr><td>%s</td><td>%f</td><td>%f</td><td>%s</td><td>%s</td><td>%d</td><td>%s</td></tr>";

// 格式化超連結的模板，用於查詢特定 MAC 地址的詳細資料
// %s 會由 sprintf 替換為該列的 MAC 位址
$op1 = "<a href='listforMAC.php?MAC=%s'>Device Detail(詳細每一筆資料)</a>";

// SQL 查詢字串，用於按 MAC 地址分組並查詢血氧、心跳平均值與時間範圍、筆數
// avg(blood)：血氧平均值；avg(heartbeat)：心跳平均值
// max(systime)：最新時間；min(systime)：最舊時間；count(*)：資料筆數
$qrystr = "SELECT MAC, avg(blood) as blood,avg(heartbeat) as heartbeat, max(systime) as max,min(systime) as min, count(*) as count FROM bloodoxygen WHERE 1 group by MAC order by systime desc ;";

// 建立空陣列，用於儲存查詢結果
$d01 = array(); // 用於儲存 MAC 地址
$d02 = array(); // 用於儲存起始時間（min systime）
$d03 = array(); // 用於儲存結束時間（max systime）
$d04 = array(); // 用於儲存血氧平均值
$d05 = array(); // 用於儲存心跳平均值
$d06 = array(); // 用於儲存資料筆數

// 執行 SQL 查詢
$result = mysqli_query($link, $qrystr);

if ($result !== FALSE) { // 如果查詢成功，開始處理結果
    // 逐行遍歷查詢結果
    while ($row = mysqli_fetch_array($result)) {
        // 將查詢結果添加到各個陣列中
        array_push($d01, $row["MAC"]);       // MAC 位址
        array_push($d02, $row["min"]);       // 起始時間
        array_push($d03, $row["max"]);       // 結束時間
        array_push($d04, (float)$row["blood"]);     // 血氧平均值
        array_push($d05, (float)$row["heartbeat"]); // 心跳平均值
        array_push($d06, (int)$row["count"]);     // 資料筆數
    }
}

// 釋放查詢結果
mysqli_free_result($result);

// 關閉資料庫連接
mysqli_close($link);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php oxygentitle(); ?></title>
    <link rel="stylesheet" href="/c08/webcss.css"> <!-- 加載 CSS 樣式 -->
</head>
<body>
    <!-- 包含網頁的標題內容 -->
    <?php include("../toptitle.php"); ?>

    <div align="center"> <!-- 居中對齊 -->
        <table border="1" align="center" cellspacing="1" cellpadding="1"> <!-- 建立表格 -->
            <tr bgcolor="#CFC"> <!-- 標題行，帶有背景色 -->
                <td colspan='7'><div align='center'><?php oxygentitle(); ?></div></td> <!-- 合併七個單元格 -->
            </tr>
            <tr> <!-- 表格的標題欄 -->
                <td>MAC Address(網卡編號)</td>
                <td>BloodOxygen(血氧值)</td>
                <td>HeartBeat(心跳值)</td>
                <td>Start Date Time(起始時間)</td>
                <td>End Date Time(結束時間)</td>
                <td>Records Count(筆數)</td>
                <td>Query Detail(明細查詢)</td> <!-- 顯示細節的連結 -->
            </tr>

            <?php 
            if (count($d01) > 0) { // 如果有數據
                // 使用 for 迴圈遍歷陣列
                for ($i = 0; $i < count($d01); $i++) {
                    $op1a = sprintf($op1, $d01[$i]); // 生成每行的詳細資料連結
                    // 使用格式化字串顯示每行的內容
                    // 參數依序：MAC、血氧平均、心跳平均、起始時間、結束時間、筆數、明細連結
                    echo sprintf($subrow, $d01[$i], $d04[$i], $d05[$i], $d02[$i], $d03[$i], $d06[$i], $op1a); 
                }
            }
            ?>
        </table>
    </div>

    <!-- 包含網頁的頁尾內容 -->
    <?php
    include("../topfooter.php"); 
    ?>
</body>
</html>