<!DOCTYPE html>
<html lang="zh-Hant">
<?php
/**
 * ============================================================================
 * 程式名稱：blood2jsonwithdate.php
 * 功能說明：血氧與心跳資料查詢、圖表繪製、表格顯示、匯出 CSV / PDF / 列印
 * ============================================================================
 *
 * 【程式運作流程解說】
 * ----------------------------------------------------------------------------
 * 本程式為一個「前後端混合」的網頁，前端使用 HTML + JavaScript（Chart.js），
 * 後端使用 PHP 與 MySQL 資料庫。整體運作可分成以下幾個階段：
 *
 * 一、PHP 後端階段（伺服器端執行）
 * ----------------------------------------------------------------------------
 * 1. 引入外部資源：
 *    - include "../comlib.php"：載入共用函式庫，內含 bodytemptitle()、
 *      oxygenchatrttitle() 等自訂函數。
 *    - include "../Connections/iotcnn.php"：載入資料庫連線設定，
 *      內含 Connection() 函數用來建立 mysqli 連線。
 *
 * 2. 建立資料庫連線：
 *    - 呼叫 Connection() 取得 $link（mysqli 連線物件）。
 *
 * 3. 查詢所有 MAC 清單：
 *    - SQL：SELECT MAC FROM bloodoxygen WHERE 1 GROUP BY MAC ORDER BY MAC ASC
 *    - 使用 GROUP BY MAC 取出不重複的 MAC 位址，依 MAC 遞增排序。
 *    - 將結果逐列存入陣列 $d01，供前端下拉選單 <select id="mac"> 使用。
 *    - 查詢完成後釋放結果資源，並關閉資料庫連線（此頁之後僅靠前端
 *      fetch 向 genjsondata.php 取資料，不再使用 PHP 連線）。
 *
 * 4. 產生 HTML 下拉選單：
 *    - 若 $d01 有資料，則以 foreach 產生 <option> 標籤。
 *    - 若無資料，則顯示「（尚無 MAC 資料）」選項。
 *
 * 二、HTML 前端階段（瀏覽器端執行）
 * ----------------------------------------------------------------------------
 * 1. 載入外部套件：
 *    - Chart.js（CDN）：用來繪製三個折線圖。
 *    - html2canvas：將指定區塊轉成 Canvas 圖片。
 *    - jsPDF：將 Canvas 圖片包成 PDF 並下載。
 *
 * 2. 頁面結構：
 *    - 上方為查詢條件區（MAC 下拉選單、起始日、結束日、查詢按鈕）。
 *    - 中間為動作按鈕區（下載 CSV、列印、下載 PDF）。
 *    - 下方 #print-area 內含三個圖表區塊與一個資料表格：
 *        (1) 血氧資料圖表（chartOxygen）
 *        (2) 心跳資料圖表（chartHeart）
 *        (3) 血氧 + 心跳雙 Y 軸整合圖表（chartBoth）
 *        (4) 資料表格（data-table），由 JS 動態填入。
 *
 * 3. 頁面載入時：
 *    - window load 事件觸發 loadData()，使用預設的 MAC 與日期區間
 *      自動查詢一次資料並繪圖。
 *
 * 三、JavaScript 前端邏輯階段
 * ----------------------------------------------------------------------------
 * 1. 全域變數：
 *    - oxygenChart / heartChart / bothChart：三個 Chart.js 圖表物件。
 *    - lastMac / lastStart / lastEnd：最近一次查詢條件。
 *    - lastDateTimeArr / lastOxygenArr / lastHeartArr：最近一次查詢的資料，
 *      供 CSV / PDF 匯出使用。
 *
 * 2. loadData()：
 *    - 讀取 MAC、起始日、結束日。
 *    - 驗證 MAC 不可為空、日期不可為空。
 *    - 以 fetch 向遠端 API 取得 JSON：
 *        http://iot.arduino.org.tw:8888/c08/bloodoxygen/genjsondata.php
 *        ?MAC=xxx&start=YYYYMMDD&end=YYYYMMDD
 *    - 回應需為 OK，否則丟出錯誤。
 *    - 解析 JSON 後取得三個陣列：DateTime、Oxygen、HeartBeat。
 *    - 若資料為空或格式錯誤，則清除圖表、更新表格為空，並更新全域變數。
 *    - 將 Oxygen 與 HeartBeat 轉為數字（parseFloat），非數字轉為 null。
 *    - 計算血氧與心跳的「平均、最大、最小」及其索引位置。
 *    - 呼叫 drawOxygenChart()、drawHeartChart()、drawBothChart() 繪製圖表。
 *    - 呼叫 updateTable() 更新下方表格。
 *    - 更新全域變數 lastMac / lastStart / lastEnd / lastDateTimeArr /
 *      lastOxygenArr / lastHeartArr。
 *    - 若發生錯誤，console.error 記錄並 alert 提示，清除圖表與表格。
 *
 * 3. destroyCharts()：
 *    - 若三個圖表物件存在，呼叫 destroy() 釋放資源並設為 null。
 *
 * 4. drawOxygenChart()：
 *    - 繪製血氧折線圖，包含四條資料集：
 *        (1) 血氧實際值（青色實線）
 *        (2) 平均血氧（橘色虛線）
 *        (3) 最高血氧（紅色單點）
 *        (4) 最低血氧（藍色單點）
 *    - 標題包含 MAC 與查詢期間。
 *    - Y 軸建議範圍 80 ~ 100。
 *
 * 5. drawHeartChart()：
 *    - 繪製心跳折線圖，結構與血氧圖類似，但數值格式為整數（toFixed(0)）。
 *
 * 6. drawBothChart()：
 *    - 繪製血氧 + 心跳整合圖，使用雙 Y 軸：
 *        oxygenAxis（左軸）：血氧，建議範圍 80 ~ 100。
 *        heartAxis（右軸）：心跳，不畫網格線避免干擾。
 *    - 共八條資料集：血氧實際/平均/最高/最低、心跳實際/平均/最高/最低。
 *
 * 7. updateTable()：
 *    - 更新表格標題（顯示 MAC、期間、筆數或無資料）。
 *    - 清空 tbody 後，以 for 迴圈逐列建立 <tr> 與 <td>。
 *    - 血氧顯示兩位小數，心跳顯示整數，null 或非數字則顯示「—」。
 *
 * 8. downloadCSV()：
 *    - 若無資料則 alert 提示。
 *    - 以字串組出 CSV 內容（含標題列）。
 *    - 使用 Blob + URL.createObjectURL 產生下載連結，
 *      檔名格式：bloodoxygen_MAC_start_end.csv。
 *
 * 9. printChartAndTable()：
 *    - 若無資料則 confirm 詢問是否仍要列印。
 *    - 呼叫 window.print()，配合 CSS @media print 隱藏查詢區與按鈕。
 *
 * 10. downloadPDF()：
 *    - 若無資料則 confirm 詢問是否仍要轉 PDF。
 *    - 使用 html2canvas 將 #print-area 轉成 Canvas（scale: 2 提高解析度）。
 *    - 使用 jsPDF 建立 A4 直式 PDF，計算縮放比例讓圖片置中。
 *    - 檔名格式：bloodoxygen_MAC_start_end.pdf。
 *
 * 四、CSS 樣式階段
 * ----------------------------------------------------------------------------
 * - 設定 wrapper 最大寬度 1100px 並置中。
 * - 圖表區塊高度 360px，canvas 寬度 100%。
 * - 表格使用 border-collapse，偶數列淡灰背景。
 * - @media print：列印時隱藏查詢條件區、動作按鈕區與 h1 標題。
 *
 * 【注意事項】
 * ----------------------------------------------------------------------------
 * - 本程式使用固定 IP 的遠端 API（iot.arduino.org.tw:8888），若該主機無法
 *   連線，將導致查詢失敗。
 * - genjsondata.php 需回傳格式為 { DateTime: [], Oxygen: [], HeartBeat: [] }。
 * - 若網站使用 HTTPS，瀏覽器可能阻擋 HTTP 的混合內容請求。
 * - Chart.js、html2canvas、jsPDF 皆使用 CDN，需網路連線才能載入。
 * - 日期格式固定為 YYYYMMDD，未做嚴格格式驗證。
 * ============================================================================
 */

// 載入共用函式庫，例如自定義的工具函數
include("../comlib.php");

// 載入資料庫連線設定與函數（應該定義有 Connection() 函數）
include("../Connections/iotcnn.php");

// 使用 Connection() 函式建立與資料庫的連線
$link = Connection();

// 取得所有 MAC 清單，供下拉選單使用（資料表假設為 bloodoxygen）
// 使用 GROUP BY MAC 取出不重複的 MAC，並依 MAC 遞增排序
$qrystr = "SELECT MAC FROM bloodoxygen WHERE 1 GROUP BY MAC ORDER BY MAC ASC";

$d01 = array(); // 用於儲存 MAC 地址

// 執行 SQL 查詢
$result = mysqli_query($link, $qrystr);
if ($result) {
    // 逐列讀取 MAC 並存入陣列
    while ($row = mysqli_fetch_array($result)) {
        $d01[] = $row["MAC"];
    }
    // 釋放查詢結果資源
    mysqli_free_result($result);
}
// 關閉連線（此頁之後只靠 genjsondata.php 取資料）
mysqli_close($link);
?>
<head>
  <meta charset="utf-8" />
  <!-- 網頁標題，透過 comlib.php 中的 oxygenchatrttitle() 函數產生 -->
  <title><?php oxygenchatrttitle(); ?></title>
  <!-- 載入外部 CSS 樣式表 -->
  <link rel="stylesheet" href="/c08/webcss.css">
  <!-- RWD 響應式設計：設定視窗寬度與初始縮放 -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Chart.js CDN：用來繪製折線圖 -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <!-- html2canvas：將 DOM 區塊轉成 Canvas 圖片 -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <!-- jsPDF：將圖片包成 PDF 並下載 -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

  <style>
    /* 頁面主體：設定字型與移除預設邊距 */
    body {
      font-family: "Microsoft JhengHei", Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    /* 內容包裝容器：最大寬度 1100px 並置中 */
    .wrapper {
      max-width: 1100px;
      margin: 0 auto;
      padding: 16px;
    }
    /* 主標題樣式 */
    h1 {
      font-size: 24px;
      margin-bottom: 12px;
    }
    /* 次標題樣式（用於各圖表區塊標題） */
    h2 {
      font-size: 18px;
      margin-top: 24px;
      margin-bottom: 8px;
    }
    /* 查詢條件區塊列 */
    .form-row {
      margin-bottom: 12px;
    }
    /* 動作按鈕區塊列 */
    .action-row {
      margin-bottom: 16px;
    }
    /* 表單標籤樣式 */
    label {
      margin-right: 4px;
    }
    /* 文字輸入框與下拉選單樣式 */
    input[type="text"],
    select {
      padding: 4px 6px;
      margin-right: 8px;
    }
    /* 按鈕樣式 */
    button {
      padding: 6px 12px;
      cursor: pointer;
      margin-right: 6px;
      margin-top: 4px;
    }
    /* 圖表區塊：固定高度 360px，上下留白 */
    .chart-block {
      margin-top: 8px;
      margin-bottom: 24px;
      height: 360px;
    }
    /* Canvas 自適應寬度 */
    canvas {
      width: 100%;
      max-width: 1100px;
      height: 100%;
    }

    /* 表格區塊樣式 */
    #table-block {
      max-width: 1100px;
      margin: 0 auto 32px auto;
    }
    /* 表格標題樣式 */
    #table-title {
      font-size: 18px;
      margin-bottom: 8px;
      font-weight: bold;
    }
    /* 表格本體：合併邊框、字型大小 */
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }
    /* 表頭背景色 */
    thead {
      background-color: #f0f0f0;
    }
    /* 儲存格框線與內距 */
    th, td {
      border: 1px solid #ccc;
      padding: 6px 8px;
      text-align: center;
      word-break: break-all;
    }
    /* 表格偶數列淡灰背景 */
    tbody tr:nth-child(even) {
      background-color: #fafafa;
    }

    /* 列印時隱藏不必要元件，只印圖表與表格 */
    @media print {
      .form-row,
      .action-row,
      h1 {
        display: none !important;
      }
      body {
        margin: 0;
        padding: 0;
      }
    }
  </style>
</head>
<body>
      <!-- 包含網頁的標題內容（toptitle.php） -->
    <?php include("../toptitle.php"); ?>
      
  <div class="wrapper">
    <!-- 主標題：透過 comlib.php 的 oxygenchatrttitle() 輸出 -->
    <h1><?php oxygenchatrttitle(); ?></h1>

    <!-- 查詢條件區：MAC + 起始日 + 結束日 -->
    <div class="form-row">
      <label for="mac">MAC：</label>
      <select id="mac">
        <?php
        // 若 PHP 有取得 MAC 清單，則逐一產生 option
        if (count($d01) > 0) {
            foreach ($d01 as $mac) {
                echo "<option value=\"{$mac}\">{$mac}</option>";
            }
        } else {
            // 若無資料，顯示提示選項
            echo "<option value=\"\">（尚無 MAC 資料）</option>";
        }
        ?>
      </select>

      <!-- 起始日輸入框，預設值 20200406 -->
      <label for="start">起始日(YYYYMMDD)：</label>
      <input type="text" id="start" value="20200406" />

      <!-- 結束日輸入框，預設值 20251231 -->
      <label for="end">結束日(YYYYMMDD)：</label>
      <input type="text" id="end" value="20251231" />

      <!-- 查詢按鈕：呼叫 loadData() -->
      <button onclick="loadData()">查詢資料</button>
    </div>

    <!-- 匯出 / 列印 / PDF 按鈕 -->
    <div class="action-row">
      <button onclick="downloadCSV()">下載 Excel (CSV)</button>
      <button onclick="printChartAndTable()">列印圖表與表格</button>
      <button onclick="downloadPDF()">下載 PDF</button>
    </div>

    <!-- 圖表 + 表格都包在 print-area，給列印與 PDF 用 -->
    <div id="print-area">
      <!-- 圖表 1：血氧資料圖表 -->
      <h2>血氧資料圖表</h2>
      <div class="chart-block">
        <canvas id="chartOxygen"></canvas>
      </div>

      <!-- 圖表 2：心跳資料圖表 -->
      <h2>心跳資料圖表</h2>
      <div class="chart-block">
        <canvas id="chartHeart"></canvas>
      </div>

      <!-- 圖表 3：血氧 + 心跳雙 Y 軸圖表 -->
      <h2>血氧與心跳整合圖表</h2>
      <div class="chart-block">
        <canvas id="chartBoth"></canvas>
      </div>

      <!-- 資料表格：顯示 JSON 內容 -->
      <div id="table-block">
        <div id="table-title">（尚未載入資料）</div>
        <table id="data-table">
          <thead>
            <tr>
              <th>序號</th>
              <th>量測時間 (DateTime)</th>
              <th>血氧 (Spo2 %)</th>
              <th>心跳 (BPM)</th>
            </tr>
          </thead>
          <tbody>
            <!-- 由 JS 動態填入 -->
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    // 全域變數：用來存放 Chart.js 圖表物件
    let oxygenChart = null;
    let heartChart = null;
    let bothChart = null;

    // 全域變數：紀錄最近一次查詢資料，供 CSV / 列印 / PDF 使用
    let lastMac = '';
    let lastStart = '';
    let lastEnd = '';
    let lastDateTimeArr = [];
    let lastOxygenArr = [];
    let lastHeartArr = [];

    // 從後端 genjsondata.php 取得 JSON，然後畫三個 Chart.js 曲線圖 + 更新表格
    function loadData() {
      // 讀取查詢條件
      const mac = document.getElementById('mac').value;
      const start = document.getElementById('start').value;
      const end = document.getElementById('end').value;

      // 驗證 MAC 不可為空
      if (!mac) {
        alert('請先選擇 MAC！');
        return;
      }

      // 驗證日期不可為空
      if (!start || !end) {
        alert('請輸入起始日與結束日（YYYYMMDD）');
        return;
      }

      // 組合 API 網址，參數以 encodeURIComponent 編碼避免特殊字元問題
      const url =
        'http://iot.arduino.org.tw:8888/c08/bloodoxygen/genjsondata.php'
        + '?MAC=' + encodeURIComponent(mac)
        + '&start=' + encodeURIComponent(start)
        + '&end=' + encodeURIComponent(end);

      // 以 fetch 向 API 取得資料
      fetch(url)
        .then(function (response) {
          // 若 HTTP 狀態非 2xx，丟出錯誤
          if (!response.ok) {
            throw new Error('HTTP 錯誤，狀態碼：' + response.status);
          }
          // 解析為 JSON
          return response.json();
        })
        .then(function (json) {
          // 從 JSON 取出三個陣列
          const dateTime = json.DateTime;
          const oxygen = json.Oxygen;
          const heartbeat = json.HeartBeat;

          // 若資料為空或格式不正確，清除圖表與表格並提示
          if (!dateTime || !oxygen || !heartbeat || dateTime.length === 0) {
            alert('查詢區間內沒有資料或資料格式不正確');
            destroyCharts();
            updateTable(mac, start, end, [], [], []);
            lastMac = mac;
            lastStart = start;
            lastEnd = end;
            lastDateTimeArr = [];
            lastOxygenArr = [];
            lastHeartArr = [];
            return;
          }

          // 將血氧值轉成數字，非數字則轉為 null
          const oxygenData = oxygen.map(function (v) {
            const n = parseFloat(v);
            return isNaN(n) ? null : n;
          });
          // 將心跳值轉成數字，非數字則轉為 null
          const heartData = heartbeat.map(function (v) {
            const n = parseFloat(v);
            return isNaN(n) ? null : n;
          });

          // ---- 計算血氧統計：平均 / 最大 / 最小 ----
          let oxySum = 0, oxyCount = 0;
          let oxyMax = -Infinity, oxyMin = Infinity;
          let oxyMaxIdx = -1, oxyMinIdx = -1;
          for (let i = 0; i < oxygenData.length; i++) {
            const v = oxygenData[i];
            if (v === null) continue; // 略過無效值
            oxySum += v;
            oxyCount++;
            if (v > oxyMax) { oxyMax = v; oxyMaxIdx = i; } // 更新最大值
            if (v < oxyMin) { oxyMin = v; oxyMinIdx = i; } // 更新最小值
          }
          const avgOxy = oxyCount > 0 ? oxySum / oxyCount : 0; // 平均血氧

          // ---- 計算心跳統計：平均 / 最大 / 最小 ----
          let heartSum = 0, heartCount = 0;
          let heartMax = -Infinity, heartMin = Infinity;
          let heartMaxIdx = -1, heartMinIdx = -1;
          for (let i = 0; i < heartData.length; i++) {
            const v = heartData[i];
            if (v === null) continue;
            heartSum += v;
            heartCount++;
            if (v > heartMax) { heartMax = v; heartMaxIdx = i; }
            if (v < heartMin) { heartMin = v; heartMinIdx = i; }
          }
          const avgHeart = heartCount > 0 ? heartSum / heartCount : 0; // 平均心跳

          // 畫三個圖表
          drawOxygenChart(
            mac, start, end, dateTime,
            oxygenData, avgOxy,
            oxyMax, oxyMaxIdx, oxyMin, oxyMinIdx
          );

          drawHeartChart(
            mac, start, end, dateTime,
            heartData, avgHeart,
            heartMax, heartMaxIdx, heartMin, heartMinIdx
          );

          drawBothChart(
            mac, start, end, dateTime,
            oxygenData, heartData,
            avgOxy, avgHeart,
            oxyMax, oxyMaxIdx, oxyMin, oxyMinIdx,
            heartMax, heartMaxIdx, heartMin, heartMinIdx
          );

          // 更新下方表格
          updateTable(mac, start, end, dateTime, oxygenData, heartData);

          // 更新全域最近一次查詢資料
          lastMac = mac;
          lastStart = start;
          lastEnd = end;
          lastDateTimeArr = dateTime;
          lastOxygenArr = oxygenData;
          lastHeartArr = heartData;
        })
        .catch(function (error) {
          // 發生錯誤時記錄並提示，清除圖表與表格
          console.error('讀取資料時發生錯誤：', error);
          alert('讀取資料時發生錯誤，請稍後再試或檢查伺服器。');
          destroyCharts();
          updateTable(mac, start, end, [], [], []);
          lastMac = mac;
          lastStart = start;
          lastEnd = end;
          lastDateTimeArr = [];
          lastOxygenArr = [];
          lastHeartArr = [];
        });
    }

    // 銷毀舊的圖表，釋放資源
    function destroyCharts() {
      if (oxygenChart !== null) {
        oxygenChart.destroy();
        oxygenChart = null;
      }
      if (heartChart !== null) {
        heartChart.destroy();
        heartChart = null;
      }
      if (bothChart !== null) {
        bothChart.destroy();
        bothChart = null;
      }
    }

    // 圖表 1：血氧資料圖表 + 平均線 + 最高/最低點
    function drawOxygenChart(mac, start, end, labels,
                             oxygenData, avgOxy,
                             maxVal, maxIdx, minVal, minIdx) {

      const ctx = document.getElementById('chartOxygen').getContext('2d');
      // 若舊圖表存在，先銷毀
      if (oxygenChart !== null) {
        oxygenChart.destroy();
      }

      // 平均線：每個標籤點都填入相同平均值
      const avgLine = labels.map(() => avgOxy);
      // 最高點：只有最大值索引位置有值，其餘為 null
      const maxPoint = labels.map((v, i) => (i === maxIdx ? maxVal : null));
      // 最低點：只有最小值索引位置有值，其餘為 null
      const minPoint = labels.map((v, i) => (i === minIdx ? minVal : null));

      // 建立 Chart.js 折線圖
      oxygenChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: '血氧 (Spo2 %)',
              data: oxygenData,
              borderColor: 'rgba(75, 192, 192, 1)',
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderWidth: 2,
              tension: 0.2,        // 曲線平滑度
              pointRadius: 3       // 資料點半徑
            },
            {
              label: '平均血氧 (' + (isFinite(avgOxy) ? avgOxy.toFixed(2) : 'N/A') + ' %)',
              data: avgLine,
              borderColor: 'rgba(255, 159, 64, 1)',
              borderWidth: 2,
              borderDash: [6, 6],  // 虛線
              pointRadius: 0,
              tension: 0
            },
            {
              label: '最高 (' + (isFinite(maxVal) ? maxVal.toFixed(2) : 'N/A') + ' %)',
              data: maxPoint,
              borderColor: 'rgba(255, 0, 0, 1)',
              backgroundColor: 'rgba(255, 0, 0, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false      // 只顯示點，不畫線
            },
            {
              label: '最低 (' + (isFinite(minVal) ? minVal.toFixed(2) : 'N/A') + ' %)',
              data: minPoint,
              borderColor: 'rgba(0, 0, 255, 1)',
              backgroundColor: 'rgba(0, 0, 255, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: '血氧資料圖表（MAC：' + mac + '，期間：' + start + ' ~ ' + end + '）',
              font: { size: 16 }
            },
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                // 自訂 tooltip 顯示格式
                label: function (ctx) {
                  const v = ctx.parsed.y;
                  const label = ctx.dataset.label || '';
                  if (v != null && isFinite(v)) {
                    return label + ': ' + v.toFixed(2) + ' %';
                  }
                  return label + ': —';
                }
              }
            }
          },
          interaction: {
            mode: 'index',
            intersect: false
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '量測時間（DateTime）'
              },
              ticks: {
                maxRotation: 60,
                minRotation: 45
              }
            },
            y: {
              title: {
                display: true,
                text: '血氧 (Spo2 %)'
              },
              suggestedMin: 80,
              suggestedMax: 100
            }
          }
        }
      });
    }

    // 圖表 2：心跳資料圖表 + 平均線 + 最高/最低點
    function drawHeartChart(mac, start, end, labels,
                            heartData, avgHeart,
                            maxVal, maxIdx, minVal, minIdx) {

      const ctx = document.getElementById('chartHeart').getContext('2d');
      if (heartChart !== null) {
        heartChart.destroy();
      }

      const avgLine = labels.map(() => avgHeart);
      const maxPoint = labels.map((v, i) => (i === maxIdx ? maxVal : null));
      const minPoint = labels.map((v, i) => (i === minIdx ? minVal : null));

      heartChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: '心跳 (BPM)',
              data: heartData,
              borderColor: 'rgba(255, 99, 132, 1)',
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3
            },
            {
              label: '平均心跳 (' + (isFinite(avgHeart) ? avgHeart.toFixed(2) : 'N/A') + ' BPM)',
              data: avgLine,
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0
            },
            {
              label: '最高 (' + (isFinite(maxVal) ? maxVal.toFixed(0) : 'N/A') + ' BPM)',
              data: maxPoint,
              borderColor: 'rgba(255, 0, 0, 1)',
              backgroundColor: 'rgba(255, 0, 0, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false
            },
            {
              label: '最低 (' + (isFinite(minVal) ? minVal.toFixed(0) : 'N/A') + ' BPM)',
              data: minPoint,
              borderColor: 'rgba(0, 0, 255, 1)',
              backgroundColor: 'rgba(0, 0, 255, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: '心跳資料圖表（MAC：' + mac + '，期間：' + start + ' ~ ' + end + '）',
              font: { size: 16 }
            },
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: function (ctx) {
                  const v = ctx.parsed.y;
                  const label = ctx.dataset.label || '';
                  if (v != null && isFinite(v)) {
                    return label + ': ' + v.toFixed(0) + ' 次/分';
                  }
                  return label + ': —';
                }
              }
            }
          },
          interaction: {
            mode: 'index',
            intersect: false
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '量測時間（DateTime）'
              },
              ticks: {
                maxRotation: 60,
                minRotation: 45
              }
            },
            y: {
              title: {
                display: true,
                text: '心跳 (BPM)'
              }
            }
          }
        }
      });
    }

    // 圖表 3：血氧 + 心跳 雙 Y 軸圖表 + 各自平均線 + 各自最高/最低點
    function drawBothChart(mac, start, end, labels,
                           oxyData, heartData,
                           avgOxy, avgHeart,
                           oxyMax, oxyMaxIdx, oxyMin, oxyMinIdx,
                           heartMax, heartMaxIdx, heartMin, heartMinIdx) {

      const ctx = document.getElementById('chartBoth').getContext('2d');
      if (bothChart !== null) {
        bothChart.destroy();
      }

      // 血氧平均線與心跳平均線
      const avgOxyLine = labels.map(() => avgOxy);
      const avgHeartLine = labels.map(() => avgHeart);

      // 血氧最高/最低點
      const oxyMaxPoint = labels.map((v, i) => (i === oxyMaxIdx ? oxyMax : null));
      const oxyMinPoint = labels.map((v, i) => (i === oxyMinIdx ? oxyMin : null));
      // 心跳最高/最低點
      const heartMaxPoint = labels.map((v, i) => (i === heartMaxIdx ? heartMax : null));
      const heartMinPoint = labels.map((v, i) => (i === heartMinIdx ? heartMin : null));

      bothChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            // ---- 左軸：血氧相關 ----
            {
              label: '血氧 (Spo2 %)',
              data: oxyData,
              yAxisID: 'oxygenAxis',
              borderColor: 'rgba(75, 192, 192, 1)',
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3
            },
            {
              label: '平均血氧 (' + (isFinite(avgOxy) ? avgOxy.toFixed(2) : 'N/A') + ' %)',
              data: avgOxyLine,
              yAxisID: 'oxygenAxis',
              borderColor: 'rgba(255, 206, 86, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0
            },
            {
              label: '血氧最高 (' + (isFinite(oxyMax) ? oxyMax.toFixed(2) : 'N/A') + ' %)',
              data: oxyMaxPoint,
              yAxisID: 'oxygenAxis',
              borderColor: 'rgba(255, 0, 0, 1)',
              backgroundColor: 'rgba(255, 0, 0, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false
            },
            {
              label: '血氧最低 (' + (isFinite(oxyMin) ? oxyMin.toFixed(2) : 'N/A') + ' %)',
              data: oxyMinPoint,
              yAxisID: 'oxygenAxis',
              borderColor: 'rgba(0, 0, 255, 1)',
              backgroundColor: 'rgba(0, 0, 255, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false            },
            // ---- 右軸：心跳相關 ----
            {
              label: '心跳 (BPM)',
              data: heartData,
              yAxisID: 'heartAxis',
              borderColor: 'rgba(255, 99, 132, 1)',
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderWidth: 2,
              tension: 0.2,
              pointRadius: 3
            },
            {
              label: '平均心跳 (' + (isFinite(avgHeart) ? avgHeart.toFixed(2) : 'N/A') + ' BPM)',
              data: avgHeartLine,
              yAxisID: 'heartAxis',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 2,
              borderDash: [6, 6],
              pointRadius: 0,
              tension: 0
            },
            {
              label: '心跳最高 (' + (isFinite(heartMax) ? heartMax.toFixed(0) : 'N/A') + ' BPM)',
              data: heartMaxPoint,
              yAxisID: 'heartAxis',
              borderColor: 'rgba(255, 0, 0, 1)',
              backgroundColor: 'rgba(255, 0, 0, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false
            },
            {
              label: '心跳最低 (' + (isFinite(heartMin) ? heartMin.toFixed(0) : 'N/A') + ' BPM)',
              data: heartMinPoint,
              yAxisID: 'heartAxis',
              borderColor: 'rgba(0, 0, 255, 1)',
              backgroundColor: 'rgba(0, 0, 255, 1)',
              pointRadius: 7,
              pointHoverRadius: 9,
              showLine: false
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: '血氧與心跳整合圖表（MAC：' + mac + '，期間：' + start + ' ~ ' + end + '）',
              font: { size: 16 }
            },
            legend: {
              display: true,
              position: 'top'
            },
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                // 依資料集所屬 Y 軸決定單位（% 或 次/分）
                label: function (ctx) {
                  const label = ctx.dataset.label || '';
                  const v = ctx.parsed.y;
                  if (v == null || !isFinite(v)) return label + ': —';

                  if (ctx.dataset.yAxisID === 'oxygenAxis') {
                    return label + ': ' + v.toFixed(2) + ' %';
                  } else {
                    return label + ': ' + v.toFixed(0) + ' 次/分';
                  }
                }
              }
            }
          },
          interaction: {
            mode: 'index',
            intersect: false
          },
          scales: {
            x: {
              title: {
                display: true,
                text: '量測時間（DateTime）'
              },
              ticks: {
                maxRotation: 60,
                minRotation: 45
              }
            },
            // 左 Y 軸：血氧
            oxygenAxis: {
              type: 'linear',
              position: 'left',
              title: {
                display: true,
                text: '血氧 (Spo2 %)'
              },
              suggestedMin: 80,
              suggestedMax: 100
            },
            // 右 Y 軸：心跳（不畫網格線避免與左軸重疊）
            heartAxis: {
              type: 'linear',
              position: 'right',
              title: {
                display: true,
                text: '心跳 (BPM)'
              },
              grid: {
                drawOnChartArea: false
              }
            }
          }
        }
      });
    }

    // 更新下方表格內容
    function updateTable(mac, start, end, dateTimeArr, oxygenArr, heartArr) {
      const titleEl = document.getElementById('table-title');
      const tbody = document.querySelector('#data-table tbody');

      // 更新表格標題
      if (!dateTimeArr || dateTimeArr.length === 0) {
        titleEl.textContent = 'MAC：' + mac + '　期間：' + start + ' ~ ' + end + '　（無資料）';
      } else {
        titleEl.textContent =
          'MAC：' + mac + '　期間：' + start + ' ~ ' + end +
          '　（共 ' + dateTimeArr.length + ' 筆）';
      }

      // 清空原有列
      tbody.innerHTML = '';

      // 逐筆建立表格列
      for (let i = 0; i < dateTimeArr.length; i++) {
        const tr = document.createElement('tr');

        // 序號欄
        const tdIdx = document.createElement('td');
        tdIdx.textContent = i + 1;

        // 時間欄
        const tdTime = document.createElement('td');
        tdTime.textContent = dateTimeArr[i];

        // 血氧欄
        const tdOxy = document.createElement('td');
        const ov = oxygenArr[i];
        tdOxy.textContent = (ov !== null && isFinite(ov)) ? ov.toFixed(2) : '—';

        // 心跳欄
        const tdHeart = document.createElement('td');
        const hv = heartArr[i];
        tdHeart.textContent = (hv !== null && isFinite(hv)) ? hv.toFixed(0) : '—';

        // 依序加入 tr
        tr.appendChild(tdIdx);
        tr.appendChild(tdTime);
        tr.appendChild(tdOxy);
        tr.appendChild(tdHeart);
        tbody.appendChild(tr);
      }
    }

    // 下載 CSV（Excel 可直接開啟）
    function downloadCSV() {
      // 若無資料則提示
      if (!lastDateTimeArr || lastDateTimeArr.length === 0) {
        alert('目前沒有可匯出的資料，請先查詢一次資料。');
        return;
      }

      // 組合 CSV 內容（含標題列）
      let csvContent = '序號,DateTime,血氧(Spo2%),心跳(BPM)\n';
      for (let i = 0; i < lastDateTimeArr.length; i++) {
        const idx = i + 1;
        const dt = lastDateTimeArr[i];
        const oxy = lastOxygenArr[i];
        const hb = lastHeartArr[i];
        const oxyStr = (oxy !== null && isFinite(oxy)) ? oxy.toFixed(2) : '';
        const hbStr = (hb !== null && isFinite(hb)) ? hb.toFixed(0) : '';
        csvContent += idx + ',' + dt + ',' + oxyStr + ',' + hbStr + '\n';
      }

      // 建立 Blob 並產生下載連結
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const filename = 'bloodoxygen_' + (lastMac || 'MAC') + '_' + (lastStart || '') + '_' + (lastEnd || '') + '.csv';

      // 建立隱藏 <a> 觸發下載
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    // 列印圖表與表格
    function printChartAndTable() {
      // 若無資料則詢問是否仍要列印
      if (!lastDateTimeArr || lastDateTimeArr.length === 0) {
        const ok = confirm('目前尚未載入資料，仍要列印整個頁面嗎？');
        if (!ok) return;
      }
      // 呼叫瀏覽器列印功能（配合 @media print 隱藏查詢區與按鈕）
      window.print();
    }

    // 將圖表與表格轉成 PDF 下載
    function downloadPDF() {
      // 若無資料則詢問是否仍要轉 PDF
      if (!lastDateTimeArr || lastDateTimeArr.length === 0) {
        const ok = confirm('目前尚未載入資料，仍要將目前畫面轉成 PDF 嗎？');
        if (!ok) return;
      }

      const printArea = document.getElementById('print-area');
      const { jsPDF } = window.jspdf;

      // 使用 html2canvas 將 #print-area 轉成 Canvas（scale: 2 提高解析度）
      html2canvas(printArea, { scale: 2 }).then(function (canvas) {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();

        // 計算圖片縮放比例，讓圖片不超出頁面寬度與高度
        const imgWidthPx = canvas.width;
        const imgHeightPx = canvas.height;
        const ratio = Math.min(pageWidth / imgWidthPx, (pageHeight - 20) / imgHeightPx);
        const imgWidth = imgWidthPx * ratio;
        const imgHeight = imgHeightPx * ratio;

        // 置中對齊，上方留白 10mm
        const x = (pageWidth - imgWidth) / 2;
        const y = 10;

        // 將圖片加入 PDF 並儲存
        pdf.addImage(imgData, 'PNG', x, y, imgWidth, imgHeight);
        const filename = 'bloodoxygen_' + (lastMac || 'MAC') + '_' + (lastStart || '') + '_' + (lastEnd || '') + '.pdf';
        pdf.save(filename);
      }).catch(function (err) {
        // 發生錯誤時記錄並提示
        console.error('轉換 PDF 時發生錯誤：', err);
        alert('產生 PDF 時發生錯誤，請稍後再試。');
      });
    }

    // 頁面載入時，直接先畫一次（使用預設值）
    window.addEventListener('load', function () {
      loadData();
    });
  </script>

  <!-- 在這一行「上面」已經有三個 Chart.js 的曲線圖 + 下方表格 + 匯出功能 -->
  <?php
  // 包含頁尾內容（topfooter.php）
  include '../topfooter.php';
  ?>
</body>
</html>