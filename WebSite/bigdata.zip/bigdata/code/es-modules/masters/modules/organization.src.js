/**
 * @license Highcharts JS v11.4.1 (2024-04-04)
 * Organization chart series type
 * @module highcharts/modules/organization
 * @requires highcharts
 * @requires highcharts/modules/sankey
 *
 * (c) 2019-2024 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import Highcharts from '../../Core/Globals.js';
import '../../Series/Organization/OrganizationSeries.js';
export default Highcharts;
