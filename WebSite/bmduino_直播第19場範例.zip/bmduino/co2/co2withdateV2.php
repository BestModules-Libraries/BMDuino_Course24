<?php
// 這支檔案只負責產生畫圖網頁，實際資料來源由 genco2json.php 提供
// 可用方式： co2_chart.php?MAC=083A8DF11676&start=20200406&end=20251231
$mac   = isset($_GET['MAC'])   ? $_GET['MAC']   : '083A8DF11676';
$start = isset($_GET['start']) ? $_GET['start'] : '20200406';
$end   = isset($_GET['end'])   ? $_GET['end']   : '20251231';
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>CO2 曲線圖顯示</title>

    <!-- Chart.js：畫圖用 -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- SheetJS：匯出 Excel 用 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

    <style>
        body {
            font-family: "Microsoft JhengHei", Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            margin-bottom: 10px;
        }
        .controls {
            margin-bottom: 15px;
        }
        .controls label {
            margin-right: 5px;
        }
        .controls input {
            padding: 5px 8px;
            margin-right: 10px;
        }
        .controls button {
            padding: 6px 12px;
            margin-right: 10px;
        }
        #chartContainer {
            max-width: 900px;
            height: 400px;
        }
        #message {
            margin-top: 10px;
            color: red;
        }
    </style>
</head>
<body>
<h2>CO2 感測資料曲線圖</h2>

<div class="controls">
    <label>MAC：</label>
    <input type="text" id="mac" value="<?php echo htmlspecialchars($mac); ?>">

    <label>start：</label>
    <input type="text" id="start" value="<?php echo htmlspecialchars($start); ?>">

    <label>end：</label>
    <input type="text" id="end" value="<?php echo htmlspecialchars($end); ?>">

    <button onclick="loadData()">讀取資料</button>
    <button onclick="exportExcel()">匯出 Excel</button>
</div>

<div id="chartContainer">
    <canvas id="co2Chart"></canvas>
</div>

<div id="message"></div>

<script>
// ======================
// 全域變數：Chart 物件 + 目前資料(給匯出用)
// ======================
let co2Chart = null;
let currentLabels = [];  // DateTime
let currentCo2 = [];     // CO2
let currentDevice = '';
let currentInterval = '';

// ======================
// 從 genco2json.php 抓資料並畫圖
// ======================
async function loadData() {
    const mac   = document.getElementById('mac').value.trim();
    const start = document.getElementById('start').value.trim();
    const end   = document.getElementById('end').value.trim();
    const msgDiv = document.getElementById('message');
    msgDiv.textContent = "";

    if (!mac || !start || !end) {
        msgDiv.textContent = "請先輸入 MAC、start、end 再查詢。";
        return;
    }

    // genco2json.php 的呼叫網址（與本檔同資料夾）
    const apiUrl = `genco2json.php?MAC=${encodeURIComponent(mac)}&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;

    try {
        const resp = await fetch(apiUrl);
        if (!resp.ok) {
            throw new Error("HTTP 錯誤：" + resp.status);
        }
        const data = await resp.json();

        // 預期 JSON 結構：
        // {
        //   "Device": "083A8DF11676",
        //   "Interval": "20200406~20251231",
        //   "DateTime": [...],
        //   "co2": [...]
        // }
        const labels = data.DateTime || [];
        const co2Arr = data.co2 || [];

        if (!Array.isArray(labels) || !Array.isArray(co2Arr) || labels.length === 0) {
            msgDiv.textContent = "查無資料或 JSON 結構不正確。";
            clearChart();
            currentLabels = [];
            currentCo2 = [];
            currentDevice = '';
            currentInterval = '';
            return;
        }

        // 若長度不一致，以較小的長度為主，避免畫圖出錯
        const len = Math.min(labels.length, co2Arr.length);
        const cutLabels = labels.slice(0, len);
        const cutCo2Arr = co2Arr.slice(0, len);

        // 記錄目前資料（給匯出 Excel 用）
        currentLabels = cutLabels;
        currentCo2 = cutCo2Arr;
        currentDevice = data.Device || mac;
        currentInterval = data.Interval || (start + "~" + end);

        drawChart(cutLabels, cutCo2Arr, currentDevice, currentInterval);
    } catch (err) {
        msgDiv.textContent = "讀取或解析 JSON 發生錯誤：" + err.message;
        console.error(err);
        clearChart();
        currentLabels = [];
        currentCo2 = [];
        currentDevice = '';
        currentInterval = '';
    }
}

// ======================
// 清除現有圖表
// ======================
function clearChart() {
    if (co2Chart) {
        co2Chart.destroy();
        co2Chart = null;
    }
}

// ======================
// 畫出 CO2 曲線圖
// ======================
function drawChart(labels, co2Data, device, interval) {
    const ctx = document.getElementById('co2Chart').getContext('2d');
    clearChart();  // 若之前有圖表，先銷毀

    co2Chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,   // X 軸標籤：DateTime 陣列
            datasets: [{
                label: 'CO2 (ppm)',
                data: co2Data,   // Y 軸資料：co2 陣列
                borderWidth: 2,
                fill: false,
                tension: 0.1,    // 線條平滑程度
                pointRadius: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: `Device: ${device || ''} / Interval: ${interval || ''}`
                },
                legend: {
                    display: true
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'DateTime'
                    },
                    ticks: {
                        maxRotation: 60,
                        minRotation: 0
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'CO2 (ppm)'
                    },
                    beginAtZero: false
                }
            }
        }
    });
}

// ======================
// 匯出目前資料為 Excel 檔案
// ======================
function exportExcel() {
    const msgDiv = document.getElementById('message');

    if (!currentLabels.length || !currentCo2.length) {
        msgDiv.textContent = "目前沒有可匯出的資料，請先『讀取資料』。";
        return;
    }

    // 用二維陣列建立工作表資料
    // 第一列當標題
    const wsData = [];
    wsData.push(["Index", "DateTime", "CO2 (ppm)"]);

    for (let i = 0; i < currentLabels.length; i++) {
        wsData.push([
            i + 1,
            currentLabels[i],
            currentCo2[i]
        ]);
    }

    // 產生工作表與活頁簿
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "CO2 Data");

    // 檔名可帶上 Device 與日期區間
    const fileName = `co2_data_${currentDevice}_${currentInterval}.xlsx`.replace(/[\/\\:*?"<>|]/g, "_");

    XLSX.writeFile(wb, fileName);
}

// 頁面載入後，可以自動先畫一次（用預設值）
window.addEventListener('load', () => {
    loadData();
});
</script>
</body>
</html>
