<?php
// 這支檔案只負責產生畫圖網頁，實際資料來源由 genco2json.php 提供
// 可用方式： co2_chart.php?MAC=083A8DF11676&start=20200406&end=20251231
$mac   = isset($_GET['MAC'])   ? $_GET['MAC']   : '083A8DF11676';
$start = isset($_GET['start']) ? $_GET['start'] : '20200406';
$end   = isset($_GET['end'])   ? $_GET['end']   : '20251231';
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <title>CO2 曲線圖顯示</title>

    <!-- Chart.js：畫圖用 -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- SheetJS：匯出 Excel 用 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <!-- jsPDF + html2canvas：匯出 PDF 用 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

    <style>
        body {
            font-family: "Microsoft JhengHei", Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            margin-bottom: 10px;
        }
        .controls {
            margin-bottom: 15px;
        }
        .controls label {
            margin-right: 5px;
        }
        .controls input {
            padding: 5px 8px;
            margin-right: 10px;
        }
        .controls button {
            padding: 6px 12px;
            margin-right: 10px;
        }
        /* 報表區塊（圖 + 表） */
        #reportArea {
            max-width: 900px;
        }
        #chartContainer {
            max-width: 900px;
            height: 400px;
            margin-bottom: 15px;
        }
        #message {
            margin-top: 10px;
            color: red;
        }
        /* 資料表格樣式 */
        #dataTable {
            border-collapse: collapse;
            width: 100%;
            max-width: 900px;
        }
        #dataTable th, #dataTable td {
            border: 1px solid #bbb;
            padding: 5px 8px;
            text-align: center;
        }
        #dataTable th {
            background-color: #f2f2f2;
        }
        #tableTitle {
            margin-top: 10px;
            margin-bottom: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<h2>CO2 感測資料曲線圖</h2>

<div class="controls">
    <label>MAC：</label>
    <input type="text" id="mac" value="<?php echo htmlspecialchars($mac); ?>">

    <label>start：</label>
    <input type="text" id="start" value="<?php echo htmlspecialchars($start); ?>">

    <label>end：</label>
    <input type="text" id="end" value="<?php echo htmlspecialchars($end); ?>">

    <button onclick="loadData()">讀取資料</button>
    <button onclick="exportExcel()">匯出 Excel</button>
    <button onclick="exportPDF()">匯出 PDF</button>
</div>

<!-- 報表區：圖表 + 資料表格（一起輸出到 PDF） -->
<div id="reportArea">
    <div id="chartContainer">
        <canvas id="co2Chart"></canvas>
    </div>

    <div id="tableTitle">查詢結果資料表</div>
    <table id="dataTable">
        <thead>
            <tr>
                <th>Index</th>
                <th>DateTime</th>
                <th>CO2 (ppm)</th>
            </tr>
        </thead>
        <tbody>
            <!-- 由 JavaScript 動態產生 -->
        </tbody>
    </table>
</div>

<div id="message"></div>

<script>
// ======================
// 全域變數：Chart 物件 + 目前資料(給匯出 / 表格 / PDF 用)
// ======================
let co2Chart = null;
let currentLabels = [];  // DateTime
let currentCo2 = [];     // CO2
let currentDevice = '';
let currentInterval = '';

// ======================
// 從 genco2json.php 抓資料並畫圖 + 產生表格
// ======================
async function loadData() {
    const mac   = document.getElementById('mac').value.trim();
    const start = document.getElementById('start').value.trim();
    const end   = document.getElementById('end').value.trim();
    const msgDiv = document.getElementById('message');
    msgDiv.textContent = "";

    if (!mac || !start || !end) {
        msgDiv.textContent = "請先輸入 MAC、start、end 再查詢。";
        clearChart();
        renderTable([], []);
        return;
    }

    // genco2json.php 的呼叫網址（與本檔同資料夾）
    const apiUrl = `genco2json.php?MAC=${encodeURIComponent(mac)}&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;

    try {
        const resp = await fetch(apiUrl);
        if (!resp.ok) {
            throw new Error("HTTP 錯誤：" + resp.status);
        }
        const data = await resp.json();

        // 預期 JSON 結構：
        // {
        //   "Device": "083A8DF11676",
        //   "Interval": "20200406~20251231",
        //   "DateTime": [...],
        //   "co2": [...]
        // }
        const labels = data.DateTime || [];
        const co2Arr = data.co2 || [];

        if (!Array.isArray(labels) || !Array.isArray(co2Arr) || labels.length === 0) {
            msgDiv.textContent = "查無資料或 JSON 結構不正確。";
            clearChart();
            currentLabels = [];
            currentCo2 = [];
            currentDevice = '';
            currentInterval = '';
            renderTable([], []);
            return;
        }

        // 若長度不一致，以較小的長度為主，避免畫圖出錯
        const len = Math.min(labels.length, co2Arr.length);
        const cutLabels = labels.slice(0, len);
        const cutCo2Arr = co2Arr.slice(0, len);

        // 記錄目前資料（給匯出 Excel / 表格 / PDF 用）
        currentLabels = cutLabels;
        currentCo2 = cutCo2Arr;
        currentDevice = data.Device || mac;
        currentInterval = data.Interval || (start + "~" + end);

        drawChart(cutLabels, cutCo2Arr, currentDevice, currentInterval);
        renderTable(cutLabels, cutCo2Arr);
    } catch (err) {
        msgDiv.textContent = "讀取或解析 JSON 發生錯誤：" + err.message;
        console.error(err);
        clearChart();
        currentLabels = [];
        currentCo2 = [];
        currentDevice = '';
        currentInterval = '';
        renderTable([], []);
    }
}

// ======================
// 清除現有圖表
// ======================
function clearChart() {
    if (co2Chart) {
        co2Chart.destroy();
        co2Chart = null;
    }
}

// ======================
// 畫出 CO2 曲線圖
// ======================
function drawChart(labels, co2Data, device, interval) {
    const ctx = document.getElementById('co2Chart').getContext('2d');
    clearChart();  // 若之前有圖表，先銷毀

    co2Chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,   // X 軸標籤：DateTime 陣列
            datasets: [{
                label: 'CO2 (ppm)',
                data: co2Data,   // Y 軸資料：co2 陣列
                borderWidth: 2,
                fill: false,
                tension: 0.1,    // 線條平滑程度
                pointRadius: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: `Device: ${device || ''} / Interval: ${interval || ''}`
                },
                legend: {
                    display: true
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'DateTime'
                    },
                    ticks: {
                        maxRotation: 60,
                        minRotation: 0
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'CO2 (ppm)'
                    },
                    beginAtZero: false
                }
            }
        }
    });
}

// ======================
// 由目前資料產生表格內容
// ======================
function renderTable(labels, co2Data) {
    const tbody = document.querySelector('#dataTable tbody');
    tbody.innerHTML = ''; // 先清空

    const len = Math.min(labels.length, co2Data.length);
    for (let i = 0; i < len; i++) {
        const tr = document.createElement('tr');

        const tdIndex = document.createElement('td');
        tdIndex.textContent = i + 1;

        const tdTime = document.createElement('td');
        tdTime.textContent = labels[i];

        const tdCo2 = document.createElement('td');
        tdCo2.textContent = co2Data[i];

        tr.appendChild(tdIndex);
        tr.appendChild(tdTime);
        tr.appendChild(tdCo2);

        tbody.appendChild(tr);
    }

    // 若沒有資料，顯示一列「無資料」
    if (len === 0) {
        const tr = document.createElement('tr');
        const td = document.createElement('td');
        td.colSpan = 3;
        td.textContent = '目前無資料';
        tr.appendChild(td);
        tbody.appendChild(tr);
    }
}

// ======================
// 匯出目前資料為 Excel 檔案
// ======================
function exportExcel() {
    const msgDiv = document.getElementById('message');

    if (!currentLabels.length || !currentCo2.length) {
        msgDiv.textContent = "目前沒有可匯出的資料，請先『讀取資料』。";
        return;
    }

    // 用二維陣列建立工作表資料
    // 第一列當標題
    const wsData = [];
    wsData.push(["Index", "DateTime", "CO2 (ppm)"]);

    for (let i = 0; i < currentLabels.length; i++) {
        wsData.push([
            i + 1,
            currentLabels[i],
            currentCo2[i]
        ]);
    }

    // 產生工作表與活頁簿
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "CO2 Data");

    // 檔名可帶上 Device 與日期區間
    const fileName = `co2_data_${currentDevice}_${currentInterval}.xlsx`.replace(/[\/\\:*?"<>|]/g, "_");

    XLSX.writeFile(wb, fileName);
}

// ======================
// 匯出圖表 + 表格為 PDF 檔案
// ======================
async function exportPDF() {
    const msgDiv = document.getElementById('message');

    if (!currentLabels.length || !currentCo2.length) {
        msgDiv.textContent = "目前沒有可匯出的資料，請先『讀取資料』。";
        return;
    }
    msgDiv.textContent = "";

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');

    const report = document.getElementById('reportArea');

    // 用 html2canvas 把整個 reportArea 轉成圖片
    const canvas = await html2canvas(report, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');

    const imgWidth = 190;        // 內頁寬度 (A4 210mm - 左右各 10mm)
    const pageHeight = 297;      // A4 高度
    const imgHeight = canvas.height * imgWidth / canvas.width;

    let heightLeft = imgHeight;
    let position = 10;           // 第一頁上邊距 10mm

    pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
    heightLeft -= (pageHeight - 20);  // 扣掉一頁實際可放高度

    // 如果內容高度超過一頁，就繼續新增後面頁面
    while (heightLeft > 0) {
        pdf.addPage();
        position = heightLeft - imgHeight + 10;
        pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
        heightLeft -= (pageHeight - 20);
    }

    const fileName = `co2_report_${currentDevice}_${currentInterval}.pdf`.replace(/[\/\\:*?"<>|]/g, "_");
    pdf.save(fileName);
}

// 頁面載入後，可以自動先畫一次（用預設值）
window.addEventListener('load', () => {
    loadData();
});
</script>
</body>
</html>
