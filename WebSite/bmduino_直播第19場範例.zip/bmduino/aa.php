bbbbb

<?php 

	big.dhtdata phpinfo() ;

?>