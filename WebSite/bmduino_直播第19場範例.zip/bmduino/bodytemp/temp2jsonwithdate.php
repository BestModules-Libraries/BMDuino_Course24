<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8" />
  <title><?php systemtitle(); ?></title>

  <!-- 圖表 -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <!-- Excel 匯出 -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
  <!-- PDF 匯出 -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>

  <style>
    body { font-family: Arial, sans-serif; margin: 30px; }
    .controls { margin-bottom: 12px; }
    input, button { padding: 8px; margin: 4px; }
    #reportArea { margin-top: 16px; }
    .chart-wrap { max-width: 1000px; margin: 0 auto 24px; }
    canvas { width: 100% !important; max-width: 1000px; height: 360px !important; }
    table { border-collapse: collapse; width: 100%; max-width: 1000px; margin: 0 auto; }
    th, td { border: 1px solid #bbb; padding: 6px 8px; text-align: center; }
    th { background: #f2f2f2; }
  </style>
    <link rel="stylesheet" href="/c08/webcss.css"> <!-- 加載 CSS 樣式 -->  
</head>
<body>
    <!-- 包含標題內容 -->
    <?php include("../toptitle.php"); ?>
    
  <h2><?php systemtitle(); ?></h2>

  <div class="controls">
    <label>MAC：</label>
    <input type="text" id="mac" value="AABBCCDDEEFF" />
    <label>起始日(YYYYMMDD)：</label>
    <input type="text" id="start" value="20200406" />
    <label>結束日(YYYYMMDD)：</label>
    <input type="text" id="end" value="20251231" />
    <button onclick="loadData()">查詢資料</button>
    <button onclick="exportExcel()">匯出 Excel</button>
    <button onclick="exportPDF()">匯出 PDF</button>
    <button onclick="window.print()">列印</button>
  </div>

  <!-- 報表（整塊拿去做 PDF 匯出） -->
  <div id="reportArea">
    <div class="chart-wrap">
      <canvas id="oxygenChart"></canvas>
    </div>
    <div class="chart-wrap">
      <canvas id="heartChart"></canvas>
    </div>

    <!-- 查詢結果表格（供檢視與 Excel 匯出） -->
    <table id="dataTable">
      <thead>
        <tr>
          <th>#</th>
          <th>DateTime</th>
          <th>Oxygen (%)</th>
          <th>HeartBeat (BPM)</th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>

<script>
let chartOxy = null;
let chartHBM = null;

// 讀取資料
async function loadData() {
  const mac = document.getElementById('mac').value.trim();
  const start = document.getElementById('start').value.trim();
  const end   = document.getElementById('end').value.trim();

  const url = `genjsondata.php?MAC=${encodeURIComponent(mac)}&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;

  try {
    const resp = await fetch(url);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();

    // 從後端 JSON 取出三個陣列
    const labels = Array.isArray(data.DateTime) ? data.DateTime : [];
    const oxygen = Array.isArray(data.Oxygen) ? data.Oxygen.map(v => Number(v)) : [];
    const heart  = Array.isArray(data.HeartBeat) ? data.HeartBeat.map(v => Number(v)) : [];

    // 畫圖
    drawOxygen(labels, oxygen);
    drawHeart(labels, heart);

    // 填表
    fillTable(labels, oxygen, heart);

  } catch (err) {
    alert("資料讀取失敗：" + err.message);
  }
}

// 畫「Blood Oxygen」
function drawOxygen(labels, oxygen) {
  const ctx = document.getElementById('oxygenChart').getContext('2d');
  if (chartOxy) chartOxy.destroy();

  chartOxy = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Blood Oxygen (%)',
        data: oxygen,
        borderWidth: 2,
        fill: true,
        tension: 0.15
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: { display: true, text: 'Blood Oxygen' },
        legend: { display: true }
      },
      scales: {
        x: { title: { display: true, text: 'DateTime' } },
        y: { title: { display: true, text: 'SpO₂ (%)' }, suggestedMin: 80, suggestedMax: 100 }
      }
    }
  });
}

// 畫「Blood HeartBeat」
function drawHeart(labels, heart) {
  const ctx = document.getElementById('heartChart').getContext('2d');
  if (chartHBM) chartHBM.destroy();

  chartHBM = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Blood HeartBeat (BPM)',
        data: heart,
        borderWidth: 2,
        fill: true,
        tension: 0.15
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: { display: true, text: 'Blood HeartBeat' },
        legend: { display: true }
      },
      scales: {
        x: { title: { display: true, text: 'DateTime' } },
        y: { title: { display: true, text: 'BPM' }, suggestedMin: 40, suggestedMax: 140 }
      }
    }
  });
}

// 填表格
function fillTable(labels, oxygen, heart) {
  const tbody = document.querySelector('#dataTable tbody');
  tbody.innerHTML = '';
  const n = Math.max(labels.length, oxygen.length, heart.length);

  for (let i = 0; i < n; i++) {
    const tr = document.createElement('tr');
    const tdIdx = document.createElement('td'); tdIdx.textContent = String(i + 1);
    const tdT   = document.createElement('td'); tdT.textContent   = labels[i] ?? '';
    const tdO   = document.createElement('td'); tdO.textContent   = (oxygen[i] ?? '').toString();
    const tdH   = document.createElement('td'); tdH.textContent   = (heart[i] ?? '').toString();
    tr.appendChild(tdIdx); tr.appendChild(tdT); tr.appendChild(tdO); tr.appendChild(tdH);
    tbody.appendChild(tr);
  }
}

// 匯出 Excel：直接把表格丟給 SheetJS
function exportExcel() {
  const table = document.getElementById('dataTable');
  const wb = XLSX.utils.table_to_book(table, { sheet: 'Blood Data' });
  XLSX.writeFile(wb, 'blood_data.xlsx');
}

// 匯出 PDF：把整個 reportArea 轉成圖片塞進 PDF
async function exportPDF() {
  const { jsPDF } = window.jspdf;
  const el = document.getElementById('reportArea');
  const canvas = await html2canvas(el, { scale: 2 });
  const img = canvas.toDataURL('image/png');

  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  // 等比縮放，填滿頁寬
  const imgWidth = pageWidth;
  const imgHeight = canvas.height * (imgWidth / canvas.width);

  let y = 10;
  if (imgHeight <= pageHeight - 20) {
    pdf.addImage(img, 'PNG', 0, y, imgWidth, imgHeight);
  } else {
    // 多頁處理
    let heightLeft = imgHeight;
    let position = y;
    const pageHeightPx = pageHeight;

    pdf.addImage(img, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= (pageHeightPx - y);

    while (heightLeft > 0) {
      pdf.addPage();
      position = 10 - (imgHeight - heightLeft);
      pdf.addImage(img, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeightPx;
    }
  }
  pdf.save('blood_report.pdf');
}
</script>
</body>
</html>
