/*************************************************
File:             geyButtonStatus.ino
Description:      本範例為開發板連接按鈕模組的應用，
                  當接收到中斷訊號時，會透過 I2C 通訊方式
                  讀取按鈕的觸發狀態（短按或長按）。
Note:             
**************************************************/
#include <Wire.h>        // 引入 I2C（TWI）通訊的標準函式庫
#include <BMK22M131.h>   // 引入 BMK22M131 按鈕模組的函式庫

#define MaxButton 2   //目前使用LedButton模組個數
#define intPin 22     //for BMCOM1
//#define intPin 25   //for BMCOM2
// 建立一個 BMK22M131 類別的物件 myButton，使用中斷腳 D2 與 I2C 傳輸
//BMK22M131 myButton(intPin, &Wire);
BMK22M131 myButton(intPin, &Wire1);
//BMK22M131 myButton(intPin, &Wire2);

// 宣告變數 int_flag 作為中斷觸發的旗標（flag），初始值為 0
uint8_t int_flag = 0;

// 宣告變數用來儲存按鈕狀態（短按或長按）
uint8_t buttonStatus;
char allstatus[8] = {'X','X','X','X','X','X','X','X'} ;
//------------------
// 外部中斷服務函數，當按鈕腳位偵測到下降沿時執行
void ButtonInt() ;
void intLedButton() ;  //初始化聯集按鈕
String getAllButtonStatus()  ;//取得所有聯級按鈕資料

//-------------------------
// 外部中斷服務函數，當按鈕腳位偵測到下降沿時執行
void ButtonInt() 
{
  int_flag = 1;  // 設定旗標為 1，通知主程式有中斷事件
}


void intLedButton()   //初始化聯集按鈕
{
  // 將數位腳位 D2 設為外部中斷輸入腳，當發生「下降沿」（FALLING）時觸發中斷函數 ButtonInt()
  attachInterrupt(digitalPinToInterrupt(intPin), ButtonInt, FALLING);

  // 啟動按鈕模組（初始化 I2C 傳輸）
  myButton.begin();

  // 啟用按鈕模組的 LED 顯示模式（參數 1 表示開啟 LED 模式）
  myButton.ledButtonMode(1);

  // 檢查模組是否成功連線
  Serial.println("Check whether the module is connected, waiting...");
  if (myButton.isConnected() == true) 
  {
    Serial.println("The module is connecting");  // 顯示模組連線成功
  } // end of  if (myButton.isConnected() == true) 

}

String getAllButtonStatus() //取得所有聯級按鈕資料
{
  String tmp="" ;
  // 如果中斷旗標被設為 1（表示中斷事件發生）
  if (int_flag) 
  {
    int_flag = 0;  // 重設旗標，避免重複處理
    for(int i=0 ;i <MaxButton;i++ )
    {
    // 呼叫函式讀取按鈕的觸發狀態，參數 1 表示按鈕通道（或ID）
      buttonStatus = myButton.getButtonStatus(i); //取得聯集按鈕狀態
      allstatus[i] = char(48+buttonStatus) ;  //將按鈕狀態存入按鈕狀態陣列
    }
    for(int i=0 ;i <8;i++ )
    {
    // 呼叫函式讀取按鈕的觸發狀態，參數 1 表示按鈕通道（或ID）
      tmp.concat(allstatus[i]);  //將按鈕狀態陣列內容累加到字串
    }
  } //  end of if (int_flag) 
  Serial.print("All Button:(") ;
  Serial.print(tmp) ;
  Serial.print(")\n") ;
  return tmp ;
}
